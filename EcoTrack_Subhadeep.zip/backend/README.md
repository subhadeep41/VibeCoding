# EcoTrack Backend API

A .NET 8 Web API for calculating carbon footprint and environmental impact.

## Features

- **Carbon Footprint Calculation**: Calculate emissions based on transport, electricity, and food habits
- **Eco Badge System**: Get personalized eco badges based on total emissions
- **Improvement Tips**: Receive suggestions for reducing environmental impact
- **CORS Enabled**: Ready for integration with React frontend
- **Swagger Documentation**: Interactive API documentation
- **Health Check**: Monitor API status

## API Endpoints

### POST /api/CarbonFootprint/calculate
Calculate carbon footprint based on user input.

**Request Body:**
```json
{
  "dailyTravelDistance": 25.0,
  "transportMode": "car",
  "monthlyElectricityUsage": 350.0,
  "foodHabit": "omnivore"
}
```

**Response:**
```json
{
  "transport": 157.5,
  "electricity": 175.0,
  "food": 216.0,
  "total": 548.5,
  "ecoBadge": "🌍 Earth Friend",
  "improvementTip": "Consider using public transport, cycling, or walking for shorter trips to reduce transport emissions."
}
```

### GET /api/CarbonFootprint/eco-badge?totalEmissions=500
Get eco badge for a specific emissions value.

### GET /api/CarbonFootprint/health
Health check endpoint.

## Emission Factors

### Transport (kg CO2 per km)
- Car: 0.21
- Bus: 0.089
- Train: 0.041
- Bicycle: 0
- Walking: 0
- Motorcycle: 0.113

### Food (kg CO2 per day)
- Vegetarian: 3.3
- Vegan: 2.9
- Pescatarian: 3.9
- Omnivore: 7.2

### Electricity
- 0.5 kg CO2 per kWh

## Getting Started

### Prerequisites
- .NET 8 SDK
- Visual Studio 2022 or VS Code

### Running the API

1. Navigate to the backend directory:
```bash
cd backend
```

2. Restore dependencies:
```bash
dotnet restore
```

3. Run the application:
```bash
dotnet run
```

4. The API will be available at:
   - HTTPS: `https://localhost:7000`
   - HTTP: `http://localhost:5000`
   - Swagger UI: `https://localhost:7000` (root path)

### Development

To run in development mode with hot reload:
```bash
dotnet watch run
```

## Project Structure

```
backend/
├── Controllers/
│   └── CarbonFootprintController.cs
├── Models/
│   ├── UserInputRequest.cs
│   └── CarbonFootprintResponse.cs
├── Services/
│   └── CarbonFootprintService.cs
├── Program.cs
├── EcoTrack.API.csproj
├── appsettings.json
└── appsettings.Development.json
```

## Integration with Frontend

The API is configured with CORS to allow requests from:
- `http://localhost:5173` (Vite development server)
- `http://localhost:3000` (Create React App)

Update your React app to call the API endpoints instead of local calculations.
