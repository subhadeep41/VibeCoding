using Microsoft.AspNetCore.Mvc;
using EcoTrack.API.Models;
using EcoTrack.API.Services;

namespace EcoTrack.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CarbonFootprintController : ControllerBase
    {
        private readonly ICarbonFootprintService _carbonFootprintService;
        private readonly ILogger<CarbonFootprintController> _logger;

        public CarbonFootprintController(
            ICarbonFootprintService carbonFootprintService, 
            ILogger<CarbonFootprintController> logger)
        {
            _carbonFootprintService = carbonFootprintService;
            _logger = logger;
        }

        /// <summary>
        /// Calculate carbon footprint based on user input
        /// </summary>
        /// <param name="userInput">User input data for calculation</param>
        /// <returns>Carbon footprint calculation results</returns>
        [HttpPost("calculate")]
        public ActionResult<CarbonFootprintResponse> CalculateCarbonFootprint([FromBody] UserInputRequest userInput)
        {
            try
            {
                _logger.LogInformation("Calculating carbon footprint for user input");

                if (userInput == null)
                {
                    return BadRequest("User input is required");
                }

                // Validate input
                if (userInput.DailyTravelDistance < 0)
                {
                    return BadRequest("Daily travel distance cannot be negative");
                }

                if (userInput.MonthlyElectricityUsage < 0)
                {
                    return BadRequest("Monthly electricity usage cannot be negative");
                }

                if (string.IsNullOrWhiteSpace(userInput.TransportMode))
                {
                    return BadRequest("Transport mode is required");
                }

                if (string.IsNullOrWhiteSpace(userInput.FoodHabit))
                {
                    return BadRequest("Food habit is required");
                }

                var result = _carbonFootprintService.CalculateCarbonFootprint(userInput);
                
                _logger.LogInformation("Carbon footprint calculated successfully. Total: {Total} kg CO2", result.Total);
                
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error calculating carbon footprint");
                return StatusCode(500, "An error occurred while calculating carbon footprint");
            }
        }

        /// <summary>
        /// Get eco badge for a given total emissions value
        /// </summary>
        /// <param name="totalEmissions">Total emissions in kg CO2</param>
        /// <returns>Eco badge string</returns>
        [HttpGet("eco-badge")]
        public ActionResult<string> GetEcoBadge([FromQuery] double totalEmissions)
        {
            try
            {
                if (totalEmissions < 0)
                {
                    return BadRequest("Total emissions cannot be negative");
                }

                var badge = _carbonFootprintService.GetEcoBadge(totalEmissions);
                return Ok(badge);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting eco badge");
                return StatusCode(500, "An error occurred while getting eco badge");
            }
        }

        /// <summary>
        /// Health check endpoint
        /// </summary>
        /// <returns>API status</returns>
        [HttpGet("health")]
        public ActionResult<object> HealthCheck()
        {
            return Ok(new { 
                status = "healthy", 
                timestamp = DateTime.UtcNow,
                service = "EcoTrack Carbon Footprint API"
            });
        }
    }
}
