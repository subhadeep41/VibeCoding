using EcoTrack.API.Models;

namespace EcoTrack.API.Services
{
    public interface ICarbonFootprintService
    {
        CarbonFootprintResponse CalculateCarbonFootprint(UserInputRequest userInput);
        string GetEcoBadge(double totalEmissions);
        string GenerateImprovementTip(UserInputRequest userInput, CarbonFootprintResponse carbonFootprint);
    }

    public class CarbonFootprintService : ICarbonFootprintService
    {
        // Emission factors (kg CO2 per unit) - Updated based on DEFRA/EPA guidelines
        private readonly Dictionary<string, double> _transportEmissionFactors = new()
        {
            { "car", 0.21 },          // kg CO2 per km (petrol car average)
            { "bus", 0.06 },          // kg CO2 per km (public transport)
            { "train", 0.06 },        // kg CO2 per km (public transport)
            { "bicycle", 0 },         // kg CO2 per km
            { "walking", 0 },         // kg CO2 per km
            { "motorcycle", 0.113 },  // kg CO2 per km
            { "electric_car", 0.05 }, // kg CO2 per km (electric vehicle)
            { "diesel_car", 0.17 }    // kg CO2 per km (diesel car)
        };

        // Updated food emission factors (kg CO2 per day) - based on annual values
        private readonly Dictionary<string, double> _foodEmissionFactors = new()
        {
            { "vegan", 2.19 },        // kg CO2 per day (800 kg/year ÷ 365)
            { "vegetarian", 3.29 },   // kg CO2 per day (1,200 kg/year ÷ 365)
            { "low_meat", 4.11 },     // kg CO2 per day (1,500 kg/year ÷ 365)
            { "medium_meat", 5.21 },  // kg CO2 per day (1,900 kg/year ÷ 365)
            { "high_meat", 6.85 },    // kg CO2 per day (2,500 kg/year ÷ 365)
            { "omnivore", 5.21 },     // kg CO2 per day (default to medium meat)
            { "pescatarian", 3.29 }   // kg CO2 per day (similar to vegetarian)
        };

        // Updated electricity emission factor - using mixed sources grid factor
        private const double ElectricityEmissionFactor = 0.35; // kg CO2 per kWh (mixed sources)

        public CarbonFootprintResponse CalculateCarbonFootprint(UserInputRequest userInput)
        {
            // Calculate transport emissions (daily distance * 30 days * emission factor)
            // Formula: CO₂ = Distance × Emission Factor
            var transportEmissions = userInput.DailyTravelDistance * 30 * 
                _transportEmissionFactors.GetValueOrDefault(userInput.TransportMode.ToLower(), 0.21); // Default to petrol car

            // Calculate electricity emissions using grid emission factor
            // Formula: CO₂ = kWh × Grid Factor
            var electricityEmissions = userInput.MonthlyElectricityUsage * ElectricityEmissionFactor;

            // Calculate food emissions (daily emissions * 30 days)
            // Based on annual dietary footprint divided by 365 days
            var foodEmissions = _foodEmissionFactors.GetValueOrDefault(userInput.FoodHabit.ToLower(), 5.21) * 30; // Default to medium meat

            // Total carbon footprint in kg CO₂e
            var total = transportEmissions + electricityEmissions + foodEmissions;

            var response = new CarbonFootprintResponse
            {
                Transport = Math.Round(transportEmissions, 2),
                Electricity = Math.Round(electricityEmissions, 2),
                Food = Math.Round(foodEmissions, 2),
                Total = Math.Round(total, 2)
            };

            response.EcoBadge = GetEcoBadge(response.Total);
            response.ImprovementTip = GenerateImprovementTip(userInput, response);

            return response;
        }

        public string GetEcoBadge(double totalEmissions)
        {
            return totalEmissions switch
            {
                < 150 => "🌟 Eco Champion",
                < 300 => "🌱 Green Warrior",
                < 500 => "♻️ Eco Conscious",
                < 750 => "🌍 Earth Friend",
                _ => "🌱 Climate Starter"
            };
        }

        public string GenerateImprovementTip(UserInputRequest userInput, CarbonFootprintResponse carbonFootprint)
        {
            var tips = new List<string>();

            // Transport tips based on highest emission category
            if (carbonFootprint.Transport > carbonFootprint.Food && carbonFootprint.Transport > carbonFootprint.Electricity)
            {
                switch (userInput.TransportMode.ToLower())
                {
                    case "car":
                        tips.Add("Consider using public transport, cycling, or walking for shorter trips. Carpooling can reduce emissions by 50%.");
                        break;
                    case "diesel_car":
                        tips.Add("Diesel cars emit less CO₂ but consider switching to electric or hybrid vehicles for even better results.");
                        break;
                    case "motorcycle":
                        tips.Add("Motorcycles are more efficient than cars, but public transport or electric alternatives are even better.");
                        break;
                    default:
                        tips.Add("Excellent transport choices! You're already making a positive environmental impact.");
                        break;
                }
            }

            // Electricity tips
            if (carbonFootprint.Electricity > carbonFootprint.Transport && carbonFootprint.Electricity > carbonFootprint.Food)
            {
                tips.Add("Switch to LED bulbs, unplug devices when not in use, and consider renewable energy sources. Smart thermostats can reduce consumption by 10-15%.");
            }

            // Food tips with updated dietary categories
            if (carbonFootprint.Food > carbonFootprint.Transport && carbonFootprint.Food > carbonFootprint.Electricity)
            {
                switch (userInput.FoodHabit.ToLower())
                {
                    case "high_meat":
                        tips.Add("Try 'Meatless Mondays' or reduce red meat consumption. Switching from high to medium meat diet can save 600kg CO₂/year.");
                        break;
                    case "medium_meat":
                    case "omnivore":
                        tips.Add("Consider incorporating more plant-based meals. Reducing meat consumption by half can lower food emissions by 25%.");
                        break;
                    case "low_meat":
                        tips.Add("You're already eating sustainably! Try buying local and seasonal produce to further reduce your impact.");
                        break;
                    case "pescatarian":
                        tips.Add("Great sustainable choice! Focus on sustainably-sourced fish and local produce for even better results.");
                        break;
                    case "vegetarian":
                        tips.Add("Excellent dietary choice for the planet! Consider organic and local produce to maximize your positive impact.");
                        break;
                    case "vegan":
                        tips.Add("Outstanding! You have the lowest food footprint. Focus on local, seasonal, and package-free options.");
                        break;
                    default:
                        tips.Add("Consider plant-based alternatives to reduce your food-related emissions significantly.");
                        break;
                }
            }

            // General tips based on total emissions
            if (tips.Count == 0)
            {
                if (carbonFootprint.Total < 200)
                {
                    tips.Add("Fantastic! You're an eco champion. Share your sustainable habits with friends and family.");
                }
                else if (carbonFootprint.Total < 400)
                {
                    tips.Add("You're doing great! Small improvements in any category can make a big difference.");
                }
                else
                {
                    tips.Add("Every step towards sustainability counts. Focus on your highest emission category for maximum impact.");
                }
            }

            return tips.First();
        }
    }
}
