namespace EcoTrack.API.Models
{
    public class CarbonFootprintResponse
    {
        public double Transport { get; set; }
        public double Electricity { get; set; }
        public double Food { get; set; }
        public double Total { get; set; }
        public string EcoBadge { get; set; } = string.Empty;
        public string ImprovementTip { get; set; } = string.Empty;
    }
}
