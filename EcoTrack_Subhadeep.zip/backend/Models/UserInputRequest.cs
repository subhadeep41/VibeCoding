namespace EcoTrack.API.Models
{
    public class UserInputRequest
    {
        public double DailyTravelDistance { get; set; }
        public string TransportMode { get; set; } = string.Empty;
        public double MonthlyElectricityUsage { get; set; }
        public string FoodHabit { get; set; } = string.Empty;
    }
}
