using EcoTrack.API.Services;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllers();

// Note: Swagger temporarily disabled due to NuGet connectivity issues
// When NuGet connectivity is restored, uncomment these lines:
// builder.Services.AddEndpointsApiExplorer();
// builder.Services.AddSwaggerGen(c =>
// {
//     c.SwaggerDoc("v1", new() { 
//         Title = "EcoTrack API", 
//         Version = "v1",
//         Description = "API for calculating carbon footprint and environmental impact"
//     });
// });

// Register services
builder.Services.AddScoped<ICarbonFootprintService, CarbonFootprintService>();
builder.Services.AddScoped<IAuthService, AuthService>();

// Add CORS
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowReactApp",
        policy =>
        {
            policy.AllowAnyOrigin() // Allow any origin for development
                  .AllowAnyHeader()
                  .AllowAnyMethod()
                  .SetPreflightMaxAge(TimeSpan.FromSeconds(86400)); // Cache preflight for 24 hours
        });
});

// Add logging
builder.Services.AddLogging();

var app = builder.Build();

// Configure the HTTP request pipeline.
// Note: Swagger temporarily disabled due to NuGet connectivity issues
// When NuGet connectivity is restored, uncomment these lines:
// if (app.Environment.IsDevelopment())
// {
//     app.UseSwagger();
//     app.UseSwaggerUI(c =>
//     {
//         c.SwaggerEndpoint("/swagger/v1/swagger.json", "EcoTrack API V1");
//         c.RoutePrefix = string.Empty; // Serve Swagger UI at the app's root
//     });
// }

app.UseHttpsRedirection();

app.UseCors("AllowReactApp");

app.UseAuthorization();

app.MapControllers();

// Add a default route for health check and API information
app.MapGet("/", () => new { 
    message = "EcoTrack API is running!", 
    timestamp = DateTime.UtcNow,
    endpoints = new {
        carbonCalculation = "/api/CarbonFootprint/calculate",
        authentication = new {
            login = "/api/auth/login",
            register = "/api/auth/register",
            demoCredentials = "/api/auth/demo-credentials"
        },
        apiDocs = "/api/docs",
        swaggerUI = "/swagger"
    }
});

// Add a simple API documentation endpoint (alternative to Swagger)
app.MapGet("/api/docs", () => new {
    title = "EcoTrack API Documentation",
    version = "v1.0",
    description = "API for calculating carbon footprint and environmental impact with user authentication",
    endpoints = new {
        authentication = new {
            login = new {
                method = "POST",
                path = "/api/auth/login",
                description = "Authenticate user with email and password",
                requestBody = new {
                    email = "string (required) - User email address",
                    password = "string (required) - User password (min 6 characters)"
                },
                responseBody = new {
                    success = "boolean - Authentication success status",
                    message = "string - Success or error message",
                    token = "string (optional) - Authentication token",
                    user = "object (optional) - User information (id, name, email, createdAt)"
                }
            },
            register = new {
                method = "POST",
                path = "/api/auth/register",
                description = "Register a new user account",
                requestBody = new {
                    name = "string (required) - Full name (min 2 characters)",
                    email = "string (required) - Valid email address",
                    password = "string (required) - Password (min 6 characters)"
                },
                responseBody = new {
                    success = "boolean - Registration success status",
                    message = "string - Success or error message",
                    token = "string (optional) - Authentication token",
                    user = "object (optional) - User information (id, name, email, createdAt)"
                }
            },
            demoCredentials = new {
                method = "GET",
                path = "/api/auth/demo-credentials",
                description = "Get demo login credentials for testing",
                responseBody = new {
                    email = "string - Demo email",
                    password = "string - Demo password",
                    message = "string - Instructions"
                }
            }
        },
        carbonCalculation = new {
            method = "POST",
            path = "/api/CarbonFootprint/calculate",
            description = "Calculate carbon footprint based on user input",
            requestBody = new {
                dailyTravelDistance = "number (required)",
                transportMode = "string (required) - car, bike, public_transport, walk",
                monthlyElectricityUsage = "number (required)",
                foodHabit = "string (required) - vegetarian, non-vegetarian, vegan"
            },
            responseBody = new {
                transport = "number - transport emissions",
                electricity = "number - electricity emissions", 
                food = "number - food emissions",
                total = "number - total emissions",
                ecoBadge = "string - environmental badge",
                improvementTip = "string - improvement suggestion"
            }
        },
        healthCheck = new {
            method = "GET",
            path = "/",
            description = "API health check and basic information"
        }
    }
});

// Add a visual Swagger-like HTML documentation endpoint
app.MapGet("/swagger", () => Results.Content(@"
<!DOCTYPE html>
<html lang='en'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>EcoTrack API Documentation</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; padding: 20px; background-color: #f5f5f5; }
        .container { max-width: 1200px; margin: 0 auto; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .header { border-bottom: 2px solid #1890ff; padding-bottom: 20px; margin-bottom: 30px; }
        .title { color: #1890ff; margin: 0; font-size: 2.5em; }
        .version { color: #666; font-size: 1.2em; margin: 5px 0; }
        .description { color: #333; font-size: 1.1em; margin: 10px 0; }
        .endpoint { border: 1px solid #d9d9d9; border-radius: 6px; margin: 20px 0; overflow: hidden; }
        .endpoint-header { background: #1890ff; color: white; padding: 15px; font-weight: bold; display: flex; align-items: center; }
        .method { background: #52c41a; padding: 4px 8px; border-radius: 4px; margin-right: 10px; font-size: 0.9em; }
        .method.post { background: #1890ff; }
        .method.get { background: #52c41a; }
        .endpoint-body { padding: 20px; }
        .section { margin: 15px 0; }
        .section-title { font-weight: bold; color: #1890ff; margin-bottom: 8px; }
        .code-block { background: #f6f8fa; border: 1px solid #e1e4e8; border-radius: 4px; padding: 15px; margin: 10px 0; font-family: 'Courier New', monospace; white-space: pre-wrap; overflow-x: auto; }
        .try-button { background: #1890ff; color: white; border: none; padding: 10px 20px; border-radius: 4px; cursor: pointer; margin: 10px 0; }
        .try-button:hover { background: #096dd9; }
        .input-group { margin: 10px 0; }
        .input-group label { display: block; margin-bottom: 5px; font-weight: bold; }
        .input-group input, .input-group select { width: 100%; padding: 8px; border: 1px solid #d9d9d9; border-radius: 4px; }
        .response-area { background: #f6f8fa; border: 1px solid #e1e4e8; border-radius: 4px; padding: 15px; margin: 10px 0; min-height: 100px; }
    </style>
</head>
<body>
    <div class='container'>
        <div class='header'>
            <h1 class='title'>EcoTrack API</h1>
            <div class='version'>Version 1.0</div>
            <div class='description'>API for calculating carbon footprint and environmental impact with user authentication</div>
        </div>

        <div class='endpoint'>
            <div class='endpoint-header'>
                <span class='method get'>GET</span>
                <span>/</span>
            </div>
            <div class='endpoint-body'>
                <div class='section'>
                    <div class='section-title'>Description</div>
                    <p>API health check and basic information</p>
                </div>
                <div class='section'>
                    <button class='try-button' onclick='testHealthCheck()'>Try it out</button>
                    <div id='health-response' class='response-area'></div>
                </div>
            </div>
        </div>

        <div class='endpoint'>
            <div class='endpoint-header'>
                <span class='method get'>GET</span>
                <span>/api/auth/demo-credentials</span>
            </div>
            <div class='endpoint-body'>
                <div class='section'>
                    <div class='section-title'>Description</div>
                    <p>Get demo login credentials for testing</p>
                </div>
                <div class='section'>
                    <button class='try-button' onclick='getDemoCredentials()'>Get Demo Credentials</button>
                    <div id='demo-response' class='response-area'></div>
                </div>
                <div class='section'>
                    <div class='section-title'>Example Response</div>
                    <div class='code-block'>{
  ""email"": ""demo@ecotrack.com"",
  ""password"": ""demo123"",
  ""message"": ""Use these credentials for demo login""
}</div>
                </div>
            </div>
        </div>

        <div class='endpoint'>
            <div class='endpoint-header'>
                <span class='method post'>POST</span>
                <span>/api/auth/login</span>
            </div>
            <div class='endpoint-body'>
                <div class='section'>
                    <div class='section-title'>Description</div>
                    <p>Authenticate user with email and password</p>
                </div>
                <div class='section'>
                    <div class='section-title'>Request Body</div>
                    <div class='input-group'>
                        <label>Email:</label>
                        <input type='email' id='loginEmail' value='demo@ecotrack.com' placeholder='Enter email'>
                    </div>
                    <div class='input-group'>
                        <label>Password:</label>
                        <input type='password' id='loginPassword' value='demo123' placeholder='Enter password'>
                    </div>
                </div>
                <div class='section'>
                    <button class='try-button' onclick='testLogin()'>Login</button>
                    <div id='login-response' class='response-area'></div>
                </div>
                <div class='section'>
                    <div class='section-title'>Example Response</div>
                    <div class='code-block'>{
  ""success"": true,
  ""message"": ""Login successful"",
  ""token"": ""eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9..."",
  ""user"": {
    ""id"": 1,
    ""name"": ""Demo User"",
    ""email"": ""demo@ecotrack.com"",
    ""createdAt"": ""2025-08-02T12:00:00Z""
  }
}</div>
                </div>
            </div>
        </div>

        <div class='endpoint'>
            <div class='endpoint-header'>
                <span class='method post'>POST</span>
                <span>/api/auth/register</span>
            </div>
            <div class='endpoint-body'>
                <div class='section'>
                    <div class='section-title'>Description</div>
                    <p>Register a new user account</p>
                </div>
                <div class='section'>
                    <div class='section-title'>Request Body</div>
                    <div class='input-group'>
                        <label>Full Name:</label>
                        <input type='text' id='registerName' value='John Doe' placeholder='Enter full name'>
                    </div>
                    <div class='input-group'>
                        <label>Email:</label>
                        <input type='email' id='registerEmail' value='john@example.com' placeholder='Enter email'>
                    </div>
                    <div class='input-group'>
                        <label>Password:</label>
                        <input type='password' id='registerPassword' value='password123' placeholder='Enter password (min 6 chars)'>
                    </div>
                </div>
                <div class='section'>
                    <button class='try-button' onclick='testRegister()'>Register</button>
                    <div id='register-response' class='response-area'></div>
                </div>
                <div class='section'>
                    <div class='section-title'>Example Response</div>
                    <div class='code-block'>{
  ""success"": true,
  ""message"": ""Registration successful"",
  ""token"": ""eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9..."",
  ""user"": {
    ""id"": 2,
    ""name"": ""John Doe"",
    ""email"": ""john@example.com"",
    ""createdAt"": ""2025-08-02T12:00:00Z""
  }
}</div>
                </div>
            </div>
        </div>

        <div class='endpoint'>
            <div class='endpoint-header'>
                <span class='method post'>POST</span>
                <span>/api/CarbonFootprint/calculate</span>
            </div>
            <div class='endpoint-body'>
                <div class='section'>
                    <div class='section-title'>Description</div>
                    <p>Calculate carbon footprint based on user input</p>
                </div>
                <div class='section'>
                    <div class='section-title'>Request Body</div>
                    <div class='input-group'>
                        <label>Daily Travel Distance (km):</label>
                        <input type='number' id='travelDistance' value='25' min='0'>
                    </div>
                    <div class='input-group'>
                        <label>Transport Mode:</label>
                        <select id='transportMode'>
                            <option value='car'>Car</option>
                            <option value='bike'>Bike</option>
                            <option value='public_transport'>Public Transport</option>
                            <option value='walk'>Walk</option>
                        </select>
                    </div>
                    <div class='input-group'>
                        <label>Monthly Electricity Usage (kWh):</label>
                        <input type='number' id='electricityUsage' value='350' min='0'>
                    </div>
                    <div class='input-group'>
                        <label>Food Habit:</label>
                        <select id='foodHabit'>
                            <option value='non-vegetarian'>Non-Vegetarian</option>
                            <option value='vegetarian'>Vegetarian</option>
                            <option value='vegan'>Vegan</option>
                        </select>
                    </div>
                </div>
                <div class='section'>
                    <button class='try-button' onclick='testCarbonCalculation()'>Calculate Carbon Footprint</button>
                    <div id='carbon-response' class='response-area'></div>
                </div>
                <div class='section'>
                    <div class='section-title'>Example Response</div>
                    <div class='code-block'>{
  ""transport"": 157.5,
  ""electricity"": 175,
  ""food"": 216,
  ""total"": 548.5,
  ""ecoBadge"": ""🌍 Earth Friend"",
  ""improvementTip"": ""Great job with your sustainable food choices! Consider buying local and seasonal produce.""
}</div>
                </div>
            </div>
        </div>
    </div>

    <script>
        async function testHealthCheck() {
            const responseDiv = document.getElementById('health-response');
            responseDiv.innerHTML = 'Loading...';
            
            try {
                const response = await fetch('/');
                const data = await response.json();
                responseDiv.innerHTML = '<strong>Status:</strong> ' + response.status + '<br><strong>Response:</strong><br>' + JSON.stringify(data, null, 2);
            } catch (error) {
                responseDiv.innerHTML = '<strong>Error:</strong> ' + error.message;
            }
        }

        async function getDemoCredentials() {
            const responseDiv = document.getElementById('demo-response');
            responseDiv.innerHTML = 'Loading...';
            
            try {
                const response = await fetch('/api/auth/demo-credentials');
                const data = await response.json();
                
                if (response.ok) {
                    responseDiv.innerHTML = '<strong>Status:</strong> ' + response.status + '<br><strong>Demo Credentials:</strong><br>' + JSON.stringify(data, null, 2);
                    // Auto-fill login form
                    document.getElementById('loginEmail').value = data.email;
                    document.getElementById('loginPassword').value = data.password;
                } else {
                    responseDiv.innerHTML = '<strong>Error:</strong> ' + response.status + '<br>' + JSON.stringify(data, null, 2);
                }
            } catch (error) {
                responseDiv.innerHTML = '<strong>Error:</strong> ' + error.message;
            }
        }

        async function testLogin() {
            const responseDiv = document.getElementById('login-response');
            responseDiv.innerHTML = 'Authenticating...';
            
            const requestData = {
                email: document.getElementById('loginEmail').value,
                password: document.getElementById('loginPassword').value
            };
            
            try {
                const response = await fetch('/api/auth/login', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(requestData)
                });
                
                const data = await response.json();
                
                if (response.ok) {
                    responseDiv.innerHTML = '<strong>Status:</strong> ' + response.status + '<br><strong>Login Result:</strong><br>' + JSON.stringify(data, null, 2);
                } else {
                    responseDiv.innerHTML = '<strong>Error:</strong> ' + response.status + '<br>' + JSON.stringify(data, null, 2);
                }
            } catch (error) {
                responseDiv.innerHTML = '<strong>Error:</strong> ' + error.message;
            }
        }

        async function testRegister() {
            const responseDiv = document.getElementById('register-response');
            responseDiv.innerHTML = 'Creating account...';
            
            const requestData = {
                name: document.getElementById('registerName').value,
                email: document.getElementById('registerEmail').value,
                password: document.getElementById('registerPassword').value
            };
            
            try {
                const response = await fetch('/api/auth/register', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(requestData)
                });
                
                const data = await response.json();
                
                if (response.ok) {
                    responseDiv.innerHTML = '<strong>Status:</strong> ' + response.status + '<br><strong>Registration Result:</strong><br>' + JSON.stringify(data, null, 2);
                } else {
                    responseDiv.innerHTML = '<strong>Error:</strong> ' + response.status + '<br>' + JSON.stringify(data, null, 2);
                }
            } catch (error) {
                responseDiv.innerHTML = '<strong>Error:</strong> ' + error.message;
            }
        }

        async function testCarbonCalculation() {
            const responseDiv = document.getElementById('carbon-response');
            responseDiv.innerHTML = 'Calculating...';
            
            const requestData = {
                dailyTravelDistance: parseFloat(document.getElementById('travelDistance').value),
                transportMode: document.getElementById('transportMode').value,
                monthlyElectricityUsage: parseFloat(document.getElementById('electricityUsage').value),
                foodHabit: document.getElementById('foodHabit').value
            };
            
            try {
                const response = await fetch('/api/CarbonFootprint/calculate', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(requestData)
                });
                
                const data = await response.json();
                
                if (response.ok) {
                    responseDiv.innerHTML = '<strong>Status:</strong> ' + response.status + '<br><strong>Carbon Footprint Result:</strong><br>' + JSON.stringify(data, null, 2);
                } else {
                    responseDiv.innerHTML = '<strong>Error:</strong> ' + response.status + '<br>' + JSON.stringify(data, null, 2);
                }
            } catch (error) {
                responseDiv.innerHTML = '<strong>Error:</strong> ' + error.message;
            }
        }
    </script>
</body>
</html>", "text/html"));

app.Run();
