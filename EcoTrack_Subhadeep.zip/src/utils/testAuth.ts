import { apiService } from '../services/api';

// Test function to verify the demo credentials
export const testBackendAuth = async () => {
  try {
    console.log('Testing backend authentication...');
    
    // Get demo credentials
    const demoData = await apiService.getDemoCredentials();
    console.log('Demo credentials:', demoData);
    
    // Test login with demo credentials
    const loginResponse = await apiService.login({
      email: demoData.email,
      password: demoData.password
    });
    
    console.log('Login response:', loginResponse);
    
    if (loginResponse.success) {
      console.log('✅ Backend authentication working!');
      return true;
    } else {
      console.log('❌ Login failed:', loginResponse.message);
      return false;
    }
  } catch (error) {
    console.error('❌ Authentication test failed:', error);
    return false;
  }
};

// Make it available in the console for testing
(window as any).testBackendAuth = testBackendAuth;
