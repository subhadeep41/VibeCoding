import React, { useState, useEffect } from 'react';
import { apiService } from '../services/api';

interface ApiStatusProps {
  className?: string;
}

const ApiStatus: React.FC<ApiStatusProps> = ({ className = '' }) => {
  const [status, setStatus] = useState<'checking' | 'online' | 'offline'>('checking');
  const [lastChecked, setLastChecked] = useState<Date | null>(null);

  const checkApiStatus = async () => {
    setStatus('checking');
    try {
      await apiService.healthCheck();
      setStatus('online');
      setLastChecked(new Date());
    } catch (error) {
      setStatus('offline');
      setLastChecked(new Date());
    }
  };

  useEffect(() => {
    checkApiStatus();
    // Check status every 30 seconds
    const interval = setInterval(checkApiStatus, 30000);
    return () => clearInterval(interval);
  }, []);

  const getStatusColor = () => {
    switch (status) {
      case 'online': return 'text-green-600 bg-green-100 border-green-200';
      case 'offline': return 'text-red-600 bg-red-100 border-red-200';
      default: return 'text-yellow-600 bg-yellow-100 border-yellow-200';
    }
  };

  const getStatusIcon = () => {
    switch (status) {
      case 'online': return '🟢';
      case 'offline': return '🔴';
      default: return '🟡';
    }
  };

  const getStatusText = () => {
    switch (status) {
      case 'online': return 'Backend API Online';
      case 'offline': return 'Backend API Offline';
      default: return 'Checking API...';
    }
  };

  return (
    <div className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-medium border ${getStatusColor()} ${className}`}>
      <span>{getStatusIcon()}</span>
      <span>{getStatusText()}</span>
      {lastChecked && status !== 'checking' && (
        <button
          onClick={checkApiStatus}
          className="ml-1 hover:opacity-70 transition-opacity"
          title="Refresh status"
        >
          🔄
        </button>
      )}
    </div>
  );
};

export default ApiStatus;
