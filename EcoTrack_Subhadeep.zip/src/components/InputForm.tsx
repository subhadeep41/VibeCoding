import React from 'react';
import type { UserInput, TransportMode, FoodHabit } from '../types';

interface InputFormProps {
  userInput: UserInput;
  onInputChange: (field: keyof UserInput, value: string | number) => void;
  onSubmit: () => void;
  loading?: boolean;
}

const InputForm: React.FC<InputFormProps> = ({ userInput, onInputChange, onSubmit, loading = false }) => {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit();
  };

  return (
    <div className="card">
      <div className="text-center mb-8">
        <div className="w-16 h-16 bg-gradient-to-r from-emerald-500 to-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
          <span className="text-3xl">🧮</span>
        </div>
        <h2 className="text-2xl font-bold text-slate-800 mb-2">Calculate Your Impact for Scope 1</h2>
        <p className="text-slate-600">Provide your details to get a personalized carbon footprint assessment</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Daily Travel Distance */}
        <div>
          <label htmlFor="dailyTravelDistance" className="block text-sm font-semibold text-slate-700 mb-3">
            Daily Travel Distance (km)
          </label>
          <div className="relative">
            <input
              type="number"
              id="dailyTravelDistance"
              value={userInput.dailyTravelDistance === 0 ? '' : userInput.dailyTravelDistance}
              onChange={(e) => {
                const value = e.target.value;
                if (value === '') {
                  onInputChange('dailyTravelDistance', 0);
                } else {
                  const numValue = parseFloat(value);
                  if (!isNaN(numValue)) {
                    onInputChange('dailyTravelDistance', numValue);
                  }
                }
              }}
              className="input-field pl-12"
              min="0"
              step="0.1"
              placeholder="Enter distance in km"
              required
            />
            <div className="absolute left-4 top-1/2 transform -translate-y-1/2 text-slate-400">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
              </svg>
            </div>
          </div>
        </div>

        {/* Transport Mode */}
        <div>
          <label htmlFor="transportMode" className="block text-sm font-semibold text-slate-700 mb-3">
            Primary Transport Mode
          </label>
          <div className="relative">
            <select
              id="transportMode"
              value={userInput.transportMode}
              onChange={(e) => onInputChange('transportMode', e.target.value as TransportMode)}
              className="input-field pl-12 appearance-none"
              required
            >
              <option value="car">🚗 Car</option>
              <option value="bus">🚌 Bus</option>
              <option value="train">🚂 Train</option>
              <option value="bike">🚴 Bike</option>
            </select>
            <div className="absolute left-4 top-1/2 transform -translate-y-1/2 text-slate-400">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4" />
              </svg>
            </div>
            <div className="absolute right-4 top-1/2 transform -translate-y-1/2 text-slate-400">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
              </svg>
            </div>
          </div>
        </div>

        {/* Monthly Electricity Usage */}
        <div>
          <label htmlFor="monthlyElectricityUsage" className="block text-sm font-semibold text-slate-700 mb-3">
            Monthly Electricity Usage (kWh)
          </label>
          <div className="relative">
            <input
              type="number"
              id="monthlyElectricityUsage"
              value={userInput.monthlyElectricityUsage === 0 ? '' : userInput.monthlyElectricityUsage}
              onChange={(e) => {
                const value = e.target.value;
                if (value === '') {
                  onInputChange('monthlyElectricityUsage', 0);
                } else {
                  const numValue = parseFloat(value);
                  if (!isNaN(numValue)) {
                    onInputChange('monthlyElectricityUsage', numValue);
                  }
                }
              }}
              className="input-field pl-12"
              min="0"
              step="0.1"
              placeholder="Enter monthly kWh usage"
              required
            />
            <div className="absolute left-4 top-1/2 transform -translate-y-1/2 text-slate-400">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
              </svg>
            </div>
          </div>
        </div>

        {/* Food Habit */}
        <div>
          <label htmlFor="foodHabit" className="block text-sm font-semibold text-slate-700 mb-3">
            Dietary Preference
          </label>
          <div className="relative">
            <select
              id="foodHabit"
              value={userInput.foodHabit}
              onChange={(e) => onInputChange('foodHabit', e.target.value as FoodHabit)}
              className="input-field pl-12 appearance-none"
              required
            >
              <option value="vegetarian">🥗 Vegetarian</option>
              <option value="non-vegetarian">🍖 Non-vegetarian</option>
            </select>
            <div className="absolute left-4 top-1/2 transform -translate-y-1/2 text-slate-400">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
              </svg>
            </div>
            <div className="absolute right-4 top-1/2 transform -translate-y-1/2 text-slate-400">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
              </svg>
            </div>
          </div>
        </div>

        <button type="submit" className="btn-primary w-full text-lg" disabled={loading}>
          {loading ? (
            <>
              <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Calculating...
            </>
          ) : (
            <>
              <span>Calculate Carbon Footprint</span>
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </>
          )}
        </button>
      </form>
    </div>
  );
};

export default InputForm;
