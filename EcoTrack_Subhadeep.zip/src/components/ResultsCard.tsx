import React from 'react';
import type { CarbonFootprint, EcoBadge } from '../types';

interface ResultsCardProps {
  carbonFootprint: CarbonFootprint;
  ecoBadge: EcoBadge;
  improvementTip: string;
}

const ResultsCard: React.FC<ResultsCardProps> = ({ carbonFootprint, ecoBadge, improvementTip }) => {
  const getBadgeColor = (badge: EcoBadge) => {
    switch (badge) {
      case 'Eco Warrior':
        return 'badge-success';
      case 'Moderate':
        return 'badge-warning';
      case 'Needs Improvement':
        return 'badge-danger';
      default:
        return 'badge badge-warning';
    }
  };

  const getProgressColor = (value: number, max: number) => {
    const percentage = (value / max) * 100;
    if (percentage < 30) return 'from-emerald-500 to-green-500';
    if (percentage < 70) return 'from-amber-500 to-orange-500';
    return 'from-red-500 to-red-600';
  };

  const maxEmission = Math.max(carbonFootprint.transport, carbonFootprint.electricity, carbonFootprint.food, 100);

  return (
    <div className="card">
      <div className="text-center mb-8">
        <div className="w-20 h-20 bg-gradient-to-r from-emerald-500 to-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
          <span className="text-4xl">📊</span>
        </div>
        <h2 className="text-3xl font-bold text-slate-800 mb-2">Your Carbon Footprint</h2>
        <p className="text-slate-600">Here's your environmental impact breakdown</p>
      </div>
      
      {/* Total Carbon Footprint */}
      <div className="mb-8">
        <div className="text-center p-8 bg-gradient-to-r from-emerald-50 to-green-50 rounded-2xl border-2 border-emerald-200">
          <div className="text-5xl font-bold bg-gradient-to-r from-emerald-600 to-green-600 bg-clip-text text-transparent mb-2">
            {carbonFootprint.total.toFixed(1)}
          </div>
          <div className="text-2xl font-semibold text-emerald-700 mb-1">kg CO₂</div>
          <div className="text-sm text-emerald-600 font-medium">per month</div>
        </div>
      </div>

      {/* Eco Badge */}
      <div className="mb-8">
        <div className="text-center">
          <div className="mb-3">
            <span className="text-lg font-semibold text-slate-700">Your Eco Rating</span>
          </div>
          <span className={`badge text-lg px-6 py-3 ${getBadgeColor(ecoBadge)}`}>
            {ecoBadge === 'Eco Warrior' && '🌟'} 
            {ecoBadge === 'Moderate' && '⚡'} 
            {ecoBadge === 'Needs Improvement' && '🔄'} 
            {ecoBadge}
          </span>
        </div>
      </div>

      {/* Breakdown */}
      <div className="mb-8">
        <h3 className="text-xl font-bold text-slate-800 mb-6">Emission Breakdown</h3>
        <div className="space-y-6">
          <div>
            <div className="flex justify-between items-center mb-2">
              <div className="flex items-center">
                <span className="text-2xl mr-3">🚗</span>
                <span className="font-semibold text-slate-700">Transport</span>
              </div>
              <span className="font-bold text-slate-800">{carbonFootprint.transport.toFixed(1)} kg CO₂</span>
            </div>
            <div className="progress-bar">
              <div 
                className={`progress-fill bg-gradient-to-r ${getProgressColor(carbonFootprint.transport, maxEmission)}`}
                style={{ width: `${(carbonFootprint.transport / maxEmission) * 100}%` }}
              ></div>
            </div>
          </div>

          <div>
            <div className="flex justify-between items-center mb-2">
              <div className="flex items-center">
                <span className="text-2xl mr-3">⚡</span>
                <span className="font-semibold text-slate-700">Electricity</span>
              </div>
              <span className="font-bold text-slate-800">{carbonFootprint.electricity.toFixed(1)} kg CO₂</span>
            </div>
            <div className="progress-bar">
              <div 
                className={`progress-fill bg-gradient-to-r ${getProgressColor(carbonFootprint.electricity, maxEmission)}`}
                style={{ width: `${(carbonFootprint.electricity / maxEmission) * 100}%` }}
              ></div>
            </div>
          </div>

          <div>
            <div className="flex justify-between items-center mb-2">
              <div className="flex items-center">
                <span className="text-2xl mr-3">🍃</span>
                <span className="font-semibold text-slate-700">Food</span>
              </div>
              <span className="font-bold text-slate-800">{carbonFootprint.food.toFixed(1)} kg CO₂</span>
            </div>
            <div className="progress-bar">
              <div 
                className={`progress-fill bg-gradient-to-r ${getProgressColor(carbonFootprint.food, maxEmission)}`}
                style={{ width: `${(carbonFootprint.food / maxEmission) * 100}%` }}
              ></div>
            </div>
          </div>

          <div className="pt-4 border-t-2 border-slate-200">
            <div className="flex justify-between items-center">
              <span className="text-xl font-bold text-slate-800">Total Impact</span>
              <span className="text-xl font-bold text-emerald-600">{carbonFootprint.total.toFixed(1)} kg CO₂</span>
            </div>
          </div>
        </div>
      </div>

      {/* Improvement Tip */}
      <div className="p-6 bg-gradient-to-r from-blue-50 to-cyan-50 border-2 border-blue-200 rounded-2xl">
        <h4 className="font-bold text-blue-800 mb-3 flex items-center text-lg">
          <span className="text-2xl mr-2">💡</span>
          Improvement Recommendation
        </h4>
        <p className="text-blue-700 leading-relaxed">{improvementTip}</p>
      </div>
    </div>
  );
};

export default ResultsCard;
