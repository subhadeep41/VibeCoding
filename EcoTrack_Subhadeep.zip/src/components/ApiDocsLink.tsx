import React from 'react';

interface ApiDocsLinkProps {
  className?: string;
}

const ApiDocsLink: React.FC<ApiDocsLinkProps> = ({ className = '' }) => {
  const handleOpenDocs = () => {
    window.open('http://localhost:5000/swagger', '_blank');
  };

  return (
    <button
      onClick={handleOpenDocs}
      className={`inline-flex items-center gap-2 px-3 py-1 text-xs font-medium text-blue-600 bg-blue-50 border border-blue-200 rounded-full hover:bg-blue-100 hover:border-blue-300 transition-colors ${className}`}
      title="View API Documentation"
    >
      <span>📚</span>
      <span>API Docs</span>
      <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
      </svg>
    </button>
  );
};

export default ApiDocsLink;
