import React, { createContext, useContext, useState, useEffect } from 'react';
import { apiService, type LoginRequest, type RegisterRequest } from '../services/api';

export interface User {
  id: number;
  name: string;
  email: string;
  createdAt: string;
}

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  login: (email: string, password: string) => Promise<void>;
  signup: (email: string, password: string, name: string) => Promise<void>;
  logout: () => void;
  loading: boolean;
  error: string | null;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: React.ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const isAuthenticated = user !== null;

  // Check for existing session on mount
  useEffect(() => {
    const savedUser = localStorage.getItem('ecotrack_user');
    if (savedUser) {
      try {
        const userData = JSON.parse(savedUser);
        setUser(userData);
      } catch (error) {
        console.error('Error parsing saved user data:', error);
        localStorage.removeItem('ecotrack_user');
      }
    }
  }, []);

  const login = async (email: string, password: string) => {
    setLoading(true);
    setError(null);

    try {
      const credentials: LoginRequest = { email, password };
      const response = await apiService.login(credentials);

      if (response.success && response.user) {
        const userData: User = {
          id: response.user.id,
          name: response.user.name,
          email: response.user.email,
          createdAt: response.user.createdAt
        };

        setUser(userData);
        localStorage.setItem('ecotrack_user', JSON.stringify(userData));
        
        // Store token if provided
        if (response.token) {
          localStorage.setItem('ecotrack_token', response.token);
        }
      } else {
        throw new Error(response.message || 'Login failed');
      }
    } catch (err: any) {
      const errorMessage = err?.message || 'Login failed';
      setError(errorMessage);
      throw new Error(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  const signup = async (email: string, password: string, name: string) => {
    setLoading(true);
    setError(null);

    try {
      const userData: RegisterRequest = { email, password, name };
      const response = await apiService.register(userData);

      if (response.success && response.user) {
        const user: User = {
          id: response.user.id,
          name: response.user.name,
          email: response.user.email,
          createdAt: response.user.createdAt
        };

        setUser(user);
        localStorage.setItem('ecotrack_user', JSON.stringify(user));
        
        // Store token if provided
        if (response.token) {
          localStorage.setItem('ecotrack_token', response.token);
        }
      } else {
        throw new Error(response.message || 'Registration failed');
      }
    } catch (err: any) {
      const errorMessage = err?.message || 'Registration failed';
      setError(errorMessage);
      throw new Error(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  const logout = () => {
    setUser(null);
    setError(null);
    localStorage.removeItem('ecotrack_user');
    localStorage.removeItem('ecotrack_token');
  };

  const value: AuthContextType = {
    user,
    isAuthenticated,
    login,
    signup,
    logout,
    loading,
    error
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};
