// API service for communicating with the EcoTrack backend
const API_BASE_URL = 'http://localhost:5000';

export interface UserInputRequest {
  dailyTravelDistance: number;
  transportMode: string;
  monthlyElectricityUsage: number;
  foodHabit: string;
}

export interface CarbonFootprintResponse {
  transport: number;
  electricity: number;
  food: number;
  total: number;
  ecoBadge: string;
  improvementTip: string;
}

export interface LoginRequest {
  email: string;
  password: string;
}

export interface RegisterRequest {
  name: string;
  email: string;
  password: string;
}

export interface UserInfo {
  id: number;
  name: string;
  email: string;
  createdAt: string;
}

export interface AuthResponse {
  success: boolean;
  message: string;
  token?: string;
  user?: UserInfo;
}

export class ApiError extends Error {
  status?: number;

  constructor(options: { message: string; status?: number }) {
    super(options.message);
    this.name = 'ApiError';
    this.status = options.status;
  }
}

class ApiService {
  private async request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
    const url = `${API_BASE_URL}${endpoint}`;
    
    const config: RequestInit = {
      headers: {
        'Content-Type': 'application/json',
        ...options.headers,
      },
      ...options,
    };

    try {
      const response = await fetch(url, config);
      
      if (!response.ok) {
        let errorMessage = `API request failed: ${response.status} ${response.statusText}`;
        
        // Try to get more detailed error from response body
        try {
          const errorData = await response.json();
          if (errorData.message) {
            errorMessage = errorData.message;
          } else if (errorData.title) {
            errorMessage = errorData.title;
          }
        } catch {
          // If response is not JSON, use default error message
        }
        
        throw new ApiError({
          message: errorMessage,
          status: response.status,
        });
      }

      return await response.json();
    } catch (error) {
      if (error instanceof ApiError) {
        throw error;
      }
      
      // Network or other errors
      const isNetworkError = error instanceof TypeError && error.message.includes('fetch');
      const errorMessage = isNetworkError 
        ? 'Unable to connect to the server. Please check if the backend is running on http://localhost:5000'
        : `Network error: ${error instanceof Error ? error.message : 'Unknown error'}`;
        
      throw new ApiError({
        message: errorMessage,
      });
    }
  }

  async calculateCarbonFootprint(input: UserInputRequest): Promise<CarbonFootprintResponse> {
    return this.request<CarbonFootprintResponse>('/api/CarbonFootprint/calculate', {
      method: 'POST',
      body: JSON.stringify(input),
    });
  }

  async login(credentials: LoginRequest): Promise<AuthResponse> {
    return this.request<AuthResponse>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify(credentials),
    });
  }

  async register(userData: RegisterRequest): Promise<AuthResponse> {
    return this.request<AuthResponse>('/api/auth/register', {
      method: 'POST',
      body: JSON.stringify(userData),
    });
  }

  async getDemoCredentials(): Promise<{ email: string; password: string; message: string }> {
    return this.request<{ email: string; password: string; message: string }>('/api/auth/demo-credentials');
  }

  async healthCheck(): Promise<{ message: string; timestamp: string; endpoints: any }> {
    return this.request<{ message: string; timestamp: string; endpoints: any }>('/');
  }
}

// Create and export a singleton instance
export const apiService = new ApiService();
