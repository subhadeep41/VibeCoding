import { useState } from 'react';
import Home from './pages/Home';
import Dashboard from './pages/DashboardNew';
import Blog from './pages/Blog';
import Analytics from './pages/Analytics';
import AuthModal from './components/AuthModal';
import SuccessNotification from './components/SuccessNotification';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { apiService, ApiError } from './services/api';
import type { UserInput, CarbonFootprint, EcoBadge } from './types';
import './utils/testAuth'; // Import test utility for development

function AppContent() {
  const [currentPage, setCurrentPage] = useState<'dashboard' | 'home' | 'blog' | 'analytics'>('dashboard');
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'signup'>('login');
  const [successNotification, setSuccessNotification] = useState<{
    isVisible: boolean;
    message: string;
  }>({ isVisible: false, message: '' });
  const { login, signup, logout, loading: authLoading, error: authError, user, isAuthenticated } = useAuth();
  const [userInput, setUserInput] = useState<UserInput>({
    dailyTravelDistance: 0,
    transportMode: 'car',
    monthlyElectricityUsage: 0,
    foodHabit: 'vegetarian'
  });

  const [carbonFootprint, setCarbonFootprint] = useState<CarbonFootprint | null>(null);
  const [showResults, setShowResults] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleInputChange = (field: keyof UserInput, value: string | number) => {
    setUserInput(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleSubmit = async () => {
    setLoading(true);
    setError(null);
    
    try {
      // Call the backend API to calculate carbon footprint
      const response = await apiService.calculateCarbonFootprint({
        dailyTravelDistance: userInput.dailyTravelDistance,
        transportMode: userInput.transportMode,
        monthlyElectricityUsage: userInput.monthlyElectricityUsage,
        foodHabit: userInput.foodHabit
      });

      // Convert API response to our CarbonFootprint interface
      const footprint: CarbonFootprint = {
        transport: response.transport,
        electricity: response.electricity,
        food: response.food,
        total: response.total,
        ecoBadge: response.ecoBadge as EcoBadge,
        improvementTip: response.improvementTip
      };

      setCarbonFootprint(footprint);
      setShowResults(true);
    } catch (err) {
      if (err instanceof ApiError) {
        setError(`Failed to calculate carbon footprint: ${err.message}`);
      } else {
        setError('An unexpected error occurred. Please try again.');
      }
      console.error('Carbon footprint calculation error:', err);
    } finally {
      setLoading(false);
    }
  };

  const navigateToHome = () => {
    setCurrentPage('home');
  };

  const navigateToDashboard = () => {
    setCurrentPage('dashboard');
    setShowResults(false);
  };

  const navigateToBlog = () => {
    setCurrentPage('blog');
  };

  const navigateToAnalytics = () => {
    setCurrentPage('analytics');
  };

  const openAuthModal = (mode: 'login' | 'signup') => {
    setAuthMode(mode);
    setAuthModalOpen(true);
  };

  const closeAuthModal = () => {
    setAuthModalOpen(false);
  };

  const toggleAuthMode = () => {
    setAuthMode(authMode === 'login' ? 'signup' : 'login');
  };

  const handleLogin = async (email: string, password: string) => {
    try {
      await login(email, password);
      setAuthModalOpen(false);
      setSuccessNotification({
        isVisible: true,
        message: `Welcome back! You have successfully logged in.`
      });
    } catch (error) {
      // Error handling is done in the AuthContext
      console.error('Login failed:', error);
    }
  };

  const handleSignup = async (email: string, password: string, name: string) => {
    try {
      await signup(email, password, name);
      setAuthModalOpen(false);
      setSuccessNotification({
        isVisible: true,
        message: `Welcome to EcoTrack, ${name}! Your account has been created successfully.`
      });
    } catch (error) {
      // Error handling is done in the AuthContext
      console.error('Signup failed:', error);
    }
  };

  const closeSuccessNotification = () => {
    setSuccessNotification({ isVisible: false, message: '' });
  };

  return (
    <>
      {currentPage === 'dashboard' ? (
        <Dashboard 
          onNavigateToHome={navigateToHome} 
          onNavigateToBlog={navigateToBlog}
          onNavigateToAnalytics={navigateToAnalytics}
          onOpenAuthModal={openAuthModal}
        />
      ) : currentPage === 'analytics' ? (
        <Analytics 
          onNavigateToHome={navigateToHome} 
          onNavigateToDashboard={navigateToDashboard}
          onNavigateToBlog={navigateToBlog}
          onOpenAuthModal={openAuthModal}
        />
      ) : currentPage === 'blog' ? (
        <Blog 
          onNavigateToHome={navigateToHome} 
          onNavigateToDashboard={navigateToDashboard}
          onNavigateToAnalytics={navigateToAnalytics}
          onOpenAuthModal={openAuthModal}
        />
      ) : (
        <Home 
          userInput={userInput}
          carbonFootprint={carbonFootprint}
          showResults={showResults}
          loading={loading}
          error={error}
          onInputChange={handleInputChange}
          onSubmit={handleSubmit}
          onNavigateToDashboard={navigateToDashboard}
          onNavigateToBlog={navigateToBlog}
          onNavigateToAnalytics={navigateToAnalytics}
          onOpenAuthModal={openAuthModal}
          user={user}
          isAuthenticated={isAuthenticated}
          onLogout={logout}
        />
      )}
      
      <AuthModal
        isOpen={authModalOpen}
        onClose={closeAuthModal}
        mode={authMode}
        onToggleMode={toggleAuthMode}
        onLogin={handleLogin}
        onSignup={handleSignup}
        loading={authLoading}
        error={authError}
      />

      <SuccessNotification
        isVisible={successNotification.isVisible}
        message={successNotification.message}
        onClose={closeSuccessNotification}
      />
    </>
  );
}

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;
