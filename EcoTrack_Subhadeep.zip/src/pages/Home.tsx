import React, { useState, useEffect } from 'react';
import InputForm from '../components/InputForm';
import ResultsCard from '../components/ResultsCard';
import ApiStatus from '../components/ApiStatus';
import ApiDocsLink from '../components/ApiDocsLink';
import type { UserInput, CarbonFootprint } from '../types';
import type { User } from '../contexts/AuthContext';

interface HomeProps {
  userInput: UserInput;
  carbonFootprint: CarbonFootprint | null;
  showResults: boolean;
  loading: boolean;
  error: string | null;
  onInputChange: (field: keyof UserInput, value: string | number) => void;
  onSubmit: () => void;
  onNavigateToDashboard: () => void;
  onNavigateToBlog?: () => void;
  onNavigateToAnalytics?: () => void;
  onOpenAuthModal?: (mode: 'login' | 'signup') => void;
  user?: User | null;
  isAuthenticated?: boolean;
  onLogout?: () => void;
}

const Home: React.FC<HomeProps> = ({ 
  userInput, 
  carbonFootprint, 
  showResults, 
  loading,
  error,
  onInputChange, 
  onSubmit,
  onNavigateToDashboard,
  onNavigateToBlog,
  onNavigateToAnalytics,
  onOpenAuthModal,
  user,
  isAuthenticated,
  onLogout
}) => {
  const [isNavVisible, setIsNavVisible] = useState(true);
  const [lastScrollY, setLastScrollY] = useState(0);
  const [isAccountDropdownOpen, setIsAccountDropdownOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      const currentScrollY = window.scrollY;
      
      if (currentScrollY < lastScrollY || currentScrollY < 100) {
        // Scrolling up or near top
        setIsNavVisible(true);
      } else {
        // Scrolling down
        setIsNavVisible(false);
      }
      
      setLastScrollY(currentScrollY);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    
    return () => window.removeEventListener('scroll', handleScroll);
  }, [lastScrollY]);
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation Bar */}
      <nav className={`fixed top-0 left-0 w-full z-50 bg-white/90 backdrop-blur-md border-b border-slate-200/50 shadow-lg transition-transform duration-300 ease-in-out ${
        isNavVisible ? 'translate-y-0' : '-translate-y-full'
      }`}>
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-r from-emerald-500 to-green-500 rounded-full flex items-center justify-center shadow-lg">
                <span className="text-2xl">🌱</span>
              </div>
              <div className="flex flex-col">
                <span className="text-2xl font-bold bg-gradient-to-r from-emerald-600 to-green-600 bg-clip-text text-transparent">
                  EcoTrack
                </span>
                <span className="text-xs text-slate-500 -mt-1">Carbon Calculator</span>
              </div>
            </div>
            
            {/* Navigation Links */}
            <div className="hidden md:flex items-center space-x-6">
              <button
                onClick={onNavigateToDashboard}
                className="text-slate-600 hover:text-emerald-600 font-medium px-3 py-2 rounded-lg hover:bg-emerald-50 transition-all duration-200"
              >
                Dashboard
              </button>
              <button
                onClick={onNavigateToAnalytics}
                className="text-slate-600 hover:text-emerald-600 font-medium px-3 py-2 rounded-lg hover:bg-emerald-50 transition-all duration-200"
              >
                Analytics
              </button>
              <button 
                onClick={onNavigateToBlog}
                className="text-slate-600 hover:text-emerald-600 font-medium px-3 py-2 rounded-lg hover:bg-emerald-50 transition-all duration-200"
              >
                Blog
              </button>
              <span className="text-emerald-600 font-semibold px-3 py-2 rounded-lg bg-emerald-50 border border-emerald-200">
                Calculator
              </span>
            </div>
            
            {/* API Status and Account Section */}
            <div className="flex items-center gap-4">
              <ApiDocsLink />
              <ApiStatus />
              
              {/* Account Dropdown */}
              <div className="relative">
                <button 
                  onClick={() => setIsAccountDropdownOpen(!isAccountDropdownOpen)}
                  className="w-10 h-10 rounded-full bg-gradient-to-br from-emerald-100 to-green-100 flex items-center justify-center border-2 border-emerald-200 shadow-sm hover:shadow-md hover:scale-105 transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:ring-offset-2"
                >
                  <svg className="w-5 h-5 text-emerald-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                  </svg>
                </button>
                
                {/* Dropdown Menu */}
                {isAccountDropdownOpen && (
                  <div className="absolute right-0 mt-2 w-56 bg-white/95 backdrop-blur-md rounded-xl shadow-xl border border-slate-200/50 py-2 z-50 animate-fadeInUp">
                    {isAuthenticated && user ? (
                      <>
                        {/* User Info Section */}
                        <div className="px-4 py-3 border-b border-slate-200/50">
                          <div className="text-sm font-medium text-emerald-700 truncate">
                            {user.name}
                          </div>
                          <div className="text-xs text-slate-500 truncate">
                            {user.email}
                          </div>
                        </div>
                        
                        {/* Logout Button */}
                        <button 
                          onClick={() => {
                            setIsAccountDropdownOpen(false);
                            onLogout?.();
                          }}
                          className="w-full text-left px-4 py-3 text-slate-700 hover:bg-red-50 hover:text-red-700 transition-colors duration-200 flex items-center gap-3"
                        >
                          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
                          </svg>
                          <span className="font-medium">Logout</span>
                        </button>
                      </>
                    ) : (
                      <>
                        {/* Login/Signup Options */}
                        <button 
                          onClick={() => {
                            setIsAccountDropdownOpen(false);
                            onOpenAuthModal?.('login');
                          }}
                          className="w-full text-left px-4 py-3 text-slate-700 hover:bg-emerald-50 hover:text-emerald-700 transition-colors duration-200 flex items-center gap-3"
                        >
                          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1" />
                          </svg>
                          <span className="font-medium">Login</span>
                        </button>
                        <button 
                          onClick={() => {
                            setIsAccountDropdownOpen(false);
                            onOpenAuthModal?.('signup');
                          }}
                          className="w-full text-left px-4 py-3 text-slate-700 hover:bg-emerald-50 hover:text-emerald-700 transition-colors duration-200 flex items-center gap-3"
                        >
                          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z" />
                          </svg>
                          <span className="font-medium">Create Account</span>
                        </button>
                      </>
                    )}
                  </div>
                )}
                
                {/* Click outside to close dropdown */}
                {isAccountDropdownOpen && (
                  <div 
                    className="fixed inset-0 z-40" 
                    onClick={() => setIsAccountDropdownOpen(false)}
                  ></div>
                )}
              </div>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-6xl mx-auto px-6 py-12 pt-24">
        <div className="grid lg:grid-cols-2 gap-12 items-start">
          {/* Input Form */}
          <div className="order-2 lg:order-1">
            <InputForm 
              userInput={userInput}
              onInputChange={onInputChange}
              onSubmit={onSubmit}
              loading={loading}
            />
            
            {/* Error Display */}
            {error && (
              <div className="mt-6 p-6 bg-red-50/80 backdrop-blur-sm border-2 border-red-200 rounded-xl">
                <div className="flex items-start">
                  <div className="w-6 h-6 bg-red-500 rounded-full flex items-center justify-center mr-3 mt-0.5 flex-shrink-0">
                    <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                    </svg>
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-red-800 mb-1">Calculation Error</h3>
                    <p className="text-red-700">{error}</p>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Results */}
          <div className="order-1 lg:order-2">
            {showResults && carbonFootprint ? (
              <ResultsCard 
                carbonFootprint={carbonFootprint}
                ecoBadge={carbonFootprint.ecoBadge}
                improvementTip={carbonFootprint.improvementTip}
              />
            ) : (
              <div className="card text-center">
                <div className="w-24 h-24 bg-gradient-to-r from-emerald-100 to-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                  <span className="text-4xl">📊</span>
                </div>
                <h3 className="text-2xl font-bold text-slate-800 mb-4">Your Results Will Appear Here</h3>
                <p className="text-slate-600 mb-6">
                  Fill out the form to calculate your carbon footprint and get personalized recommendations.
                </p>
                <div className="grid grid-cols-3 gap-4 text-center">
                  <div className="p-4 bg-gradient-to-r from-emerald-50 to-green-50 rounded-xl">
                    <div className="text-2xl mb-2">🚗</div>
                    <div className="text-sm font-medium text-slate-700">Transport Impact</div>
                  </div>
                  <div className="p-4 bg-gradient-to-r from-blue-50 to-cyan-50 rounded-xl">
                    <div className="text-2xl mb-2">⚡</div>
                    <div className="text-sm font-medium text-slate-700">Energy Usage</div>
                  </div>
                  <div className="p-4 bg-gradient-to-r from-orange-50 to-amber-50 rounded-xl">
                    <div className="text-2xl mb-2">🍃</div>
                    <div className="text-sm font-medium text-slate-700">Food Choices</div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Carbon Footprint Calculation Guide */}
        <div className="mt-8 space-y-8">
            {/* Introduction */}
            <div className="bg-white/90 backdrop-blur-sm rounded-xl p-8 border border-slate-200/50 shadow-lg">
              <div className="flex items-center mb-6">
                <div className="w-12 h-12 bg-gradient-to-r from-emerald-100 to-green-100 rounded-xl flex items-center justify-center mr-4">
                  <svg className="w-6 h-6 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-slate-800">Understanding Carbon Footprint Calculation</h2>
                  <p className="text-slate-600">Learn how we estimate your greenhouse gas emissions</p>
                </div>
              </div>
              
              <p className="text-slate-700 leading-relaxed mb-6">
                Calculating a carbon footprint involves estimating the total greenhouse gas (GHG) emissions (primarily CO₂) generated 
                directly or indirectly by a person, organization, activity, or product. Here's a breakdown of how to calculate it, 
                depending on the scope:
              </p>

              <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg p-4 border border-blue-200">
                <div className="flex items-center mb-2">
                  <svg className="w-5 h-5 text-blue-600 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  <span className="font-semibold text-blue-800">Basic Formula</span>
                </div>
                <div className="font-mono text-lg text-blue-700 bg-white/60 p-3 rounded">
                  Carbon Footprint = Σ (Activity × Emission Factor)
                </div>
                <p className="text-sm text-blue-600 mt-2">
                  Emission Factor represents how much CO₂e is emitted per unit of activity (e.g., kg CO₂ per kWh, per liter of petrol)
                </p>
              </div>
            </div>

            {/* Personal Carbon Footprint Categories */}
            <div className="bg-white/90 backdrop-blur-sm rounded-xl p-8 border border-slate-200/50 shadow-lg">
              <h3 className="text-xl font-bold text-slate-800 mb-6 flex items-center">
                <span className="text-2xl mr-3">🔹</span>
                1. Personal or Household Carbon Footprint
              </h3>
              
              <p className="text-slate-700 mb-6">You calculate emissions from four main categories:</p>
              
              <div className="overflow-x-auto">
                <table className="w-full border-collapse">
                  <thead>
                    <tr className="bg-gradient-to-r from-slate-50 to-slate-100">
                      <th className="border border-slate-300 px-4 py-3 text-left font-semibold text-slate-800">Category</th>
                      <th className="border border-slate-300 px-4 py-3 text-left font-semibold text-slate-800">What to Measure</th>
                      <th className="border border-slate-300 px-4 py-3 text-left font-semibold text-slate-800">Emission Source Example</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="hover:bg-slate-50">
                      <td className="border border-slate-300 px-4 py-3 font-medium text-orange-700">Energy Use</td>
                      <td className="border border-slate-300 px-4 py-3 text-slate-700">Electricity, gas, LPG, heating oil</td>
                      <td className="border border-slate-300 px-4 py-3 text-slate-600">Home electricity bill, cooking fuel usage</td>
                    </tr>
                    <tr className="hover:bg-slate-50">
                      <td className="border border-slate-300 px-4 py-3 font-medium text-red-700">Transport</td>
                      <td className="border border-slate-300 px-4 py-3 text-slate-700">Vehicle mileage, flights, public transport usage</td>
                      <td className="border border-slate-300 px-4 py-3 text-slate-600">Car fuel (liters), air travel (km/flights)</td>
                    </tr>
                    <tr className="hover:bg-slate-50">
                      <td className="border border-slate-300 px-4 py-3 font-medium text-green-700">Food</td>
                      <td className="border border-slate-300 px-4 py-3 text-slate-700">Diet type and food consumption</td>
                      <td className="border border-slate-300 px-4 py-3 text-slate-600">Meat-heavy vs vegetarian diets</td>
                    </tr>
                    <tr className="hover:bg-slate-50">
                      <td className="border border-slate-300 px-4 py-3 font-medium text-purple-700">Consumption</td>
                      <td className="border border-slate-300 px-4 py-3 text-slate-700">Goods, clothing, electronics, waste</td>
                      <td className="border border-slate-300 px-4 py-3 text-slate-600">Frequency of shopping, recycling habits</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            {/* Organizational Carbon Footprint */}
            <div className="bg-white/90 backdrop-blur-sm rounded-xl p-8 border border-slate-200/50 shadow-lg">
              <h3 className="text-xl font-bold text-slate-800 mb-6 flex items-center">
                <span className="text-2xl mr-3">🔹</span>
                2. Organizational/Corporate Carbon Footprint
              </h3>
              
              <p className="text-slate-700 mb-6">Usually divided into three scopes (as per the GHG Protocol):</p>
              
              <div className="overflow-x-auto">
                <table className="w-full border-collapse">
                  <thead>
                    <tr className="bg-gradient-to-r from-slate-50 to-slate-100">
                      <th className="border border-slate-300 px-4 py-3 text-left font-semibold text-slate-800">Scope</th>
                      <th className="border border-slate-300 px-4 py-3 text-left font-semibold text-slate-800">Description</th>
                      <th className="border border-slate-300 px-4 py-3 text-left font-semibold text-slate-800">Examples</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="hover:bg-slate-50">
                      <td className="border border-slate-300 px-4 py-3 font-medium text-red-700">Scope 1</td>
                      <td className="border border-slate-300 px-4 py-3 text-slate-700">Direct emissions from owned sources</td>
                      <td className="border border-slate-300 px-4 py-3 text-slate-600">Company vehicles, on-site fuel combustion</td>
                    </tr>
                    <tr className="hover:bg-slate-50">
                      <td className="border border-slate-300 px-4 py-3 font-medium text-orange-700">Scope 2</td>
                      <td className="border border-slate-300 px-4 py-3 text-slate-700">Indirect emissions from purchased energy</td>
                      <td className="border border-slate-300 px-4 py-3 text-slate-600">Electricity, steam, heating, cooling</td>
                    </tr>
                    <tr className="hover:bg-slate-50">
                      <td className="border border-slate-300 px-4 py-3 font-medium text-blue-700">Scope 3</td>
                      <td className="border border-slate-300 px-4 py-3 text-slate-700">Other indirect emissions (value chain)</td>
                      <td className="border border-slate-300 px-4 py-3 text-slate-600">Employee commuting, product lifecycle, suppliers</td>
                    </tr>
                  </tbody>
                </table>
              </div>
              
              <p className="text-sm text-slate-600 mt-4 italic">
                Each category uses activity data × emission factors (usually sourced from national or international databases).
              </p>
            </div>

            {/* Example Calculation */}
            <div className="bg-white/90 backdrop-blur-sm rounded-xl p-8 border border-slate-200/50 shadow-lg">
              <h3 className="text-xl font-bold text-slate-800 mb-6 flex items-center">
                <span className="text-2xl mr-3">🔹</span>
                Example Calculation (Personal Transport)
              </h3>
              
              <div className="bg-gradient-to-r from-emerald-50 to-green-50 rounded-lg p-6 border border-emerald-200">
                <h4 className="font-semibold text-emerald-800 mb-4">Scenario: Monthly Car Commute</h4>
                
                <div className="space-y-3 text-slate-700">
                  <div className="flex justify-between items-center py-2 border-b border-emerald-200">
                    <span>Distance driven per month:</span>
                    <span className="font-mono font-semibold">1,000 km</span>
                  </div>
                  <div className="flex justify-between items-center py-2 border-b border-emerald-200">
                    <span>Emission Factor (average petrol car):</span>
                    <span className="font-mono font-semibold">0.192 kg CO₂e/km</span>
                  </div>
                  <div className="flex justify-between items-center py-2 border-b border-emerald-200">
                    <span>Monthly Transport Emissions:</span>
                    <span className="font-mono font-semibold text-emerald-700">1,000 × 0.192 = 192 kg CO₂e</span>
                  </div>
                  <div className="flex justify-between items-center py-2 bg-emerald-100 rounded px-3">
                    <span className="font-semibold">Yearly Total:</span>
                    <span className="font-mono font-bold text-emerald-800">192 × 12 = 2,304 kg CO₂e (2.3 tons)</span>
                  </div>
                </div>
              </div>
              
              <div className="mt-6 p-4 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg border border-blue-200">
                <div className="flex items-start space-x-3">
                  <svg className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  <div>
                    <div className="font-medium text-blue-800 mb-1">Try Our Calculator</div>
                    <div className="text-blue-700 text-sm">Use the form above to calculate your personal carbon footprint using these same methodologies and emission factors.</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
      </div>
    </div>
  );
};

export default Home;
