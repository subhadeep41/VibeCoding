import React from 'react';
import carbonEnvImage from '../assets/carbon_env.jpg';

interface DashboardProps {
  onNavigateToHome: () => void;
}

const Dashboard: React.FC<DashboardProps> = ({ onNavigateToHome }) => {
  return (
    <div className="min-h-screen bg-slate-50">
      {/* Hero Section */}
      <section className="py-20">
        <div className="container mx-auto px-6">
          <div className="grid lg:grid-cols-2 gap-16 items-center min-h-[600px]">
            {/* Left Content */}
            <div className="text-left space-y-8">
              <div>
                <h1 className="text-4xl lg:text-6xl xl:text-7xl font-bold mb-8 text-slate-800 leading-tight">
                  Transform Your Impact,
                  <span className="block bg-gradient-to-r from-emerald-600 to-green-600 bg-clip-text text-transparent">
                    Save Our Planet
                  </span>
                </h1>
                <p className="text-3xl lg:text-4xl xl:text-5xl text-slate-600 mb-8 leading-relaxed font-medium">
                  Master your carbon footprint with intelligent tracking and actionable insights
                </p>
              </div>
              
              <div className="space-y-6">
                <button
                  onClick={onNavigateToHome}
                  className="bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 text-white font-semibold text-xl px-12 py-6 rounded-2xl transition-all duration-300 shadow-2xl hover:shadow-emerald-500/25 transform hover:scale-105 inline-flex items-center gap-4"
                >
                  <span>Calculate Your Carbon Footprint</span>
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                </button>
                
                <div className="flex flex-col sm:flex-row sm:space-x-12 space-y-4 sm:space-y-0 text-slate-600">
                  <div className="flex items-center space-x-3">
                    <div className="w-3 h-3 bg-emerald-500 rounded-full animate-pulse shadow-lg"></div>
                    <span className="text-lg">Real-time calculations</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="w-3 h-3 bg-blue-500 rounded-full animate-pulse shadow-lg" style={{ animationDelay: '1s' }}></div>
                    <span className="text-lg">Personalized insights</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse shadow-lg" style={{ animationDelay: '2s' }}></div>
                    <span className="text-lg">Expert recommendations</span>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Right Image */}
            <div className="relative lg:ml-8">
              <div className="relative overflow-hidden rounded-3xl shadow-2xl bg-white p-2">
                <img 
                  src={carbonEnvImage} 
                  alt="Environmental carbon tracking visualization" 
                  className="w-full h-[600px] object-cover rounded-2xl"
                />
                <div className="absolute inset-2 bg-gradient-to-br from-emerald-600/10 to-green-600/5 rounded-2xl"></div>
                
                {/* Floating Stats */}
                <div className="absolute top-8 left-8 bg-white/95 backdrop-blur-sm rounded-xl px-6 py-4 shadow-xl border border-emerald-100">
                  <div className="flex items-center space-x-3">
                    <div className="w-4 h-4 bg-green-500 rounded-full animate-pulse"></div>
                    <div>
                      <div className="text-sm font-medium text-slate-600">Carbon Saved</div>
                      <div className="text-2xl font-bold text-emerald-600">247 kg</div>
                    </div>
                  </div>
                </div>
                
                <div className="absolute bottom-8 right-8 bg-white/95 backdrop-blur-sm rounded-xl px-6 py-4 shadow-xl border border-blue-100">
                  <div className="flex items-center space-x-3">
                    <div className="w-4 h-4 bg-blue-500 rounded-full animate-pulse"></div>
                    <div>
                      <div className="text-sm font-medium text-slate-600">Impact Score</div>
                      <div className="text-2xl font-bold text-blue-600">A+</div>
                    </div>
                  </div>
                </div>
                
                <div className="absolute top-1/2 -translate-y-1/2 -right-4 bg-gradient-to-r from-emerald-500 to-green-500 text-white rounded-full px-4 py-2 shadow-lg transform rotate-12">
                  <div className="text-sm font-bold">Live Tracking</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <main className="container mx-auto px-6 py-16 -mt-10 relative z-10">
        {/* Welcome Card */}
        <div className="card mb-12">
          <div className="text-center">
            <h2 className="text-3xl font-bold text-slate-800 mb-4">
              Welcome to Your Environmental Dashboard
            </h2>
            <p className="text-lg text-slate-600 max-w-3xl mx-auto">
              Track, understand, and reduce your carbon footprint with our comprehensive suite of tools. 
              Get personalized insights and actionable recommendations to make a real difference.
            </p>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          <div className="metric-card text-center">
            <div className="w-12 h-12 bg-gradient-to-r from-emerald-500 to-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
              <span className="text-2xl">🌱</span>
            </div>
            <h3 className="text-lg font-semibold text-slate-800 mb-2">Carbon Saved</h3>
            <p className="text-3xl font-bold text-emerald-600 mb-1">0 kg CO₂</p>
            <p className="text-sm text-slate-500">This month</p>
          </div>

          <div className="metric-card text-center">
            <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full flex items-center justify-center mx-auto mb-4">
              <span className="text-2xl">📊</span>
            </div>
            <h3 className="text-lg font-semibold text-slate-800 mb-2">Calculations</h3>
            <p className="text-3xl font-bold text-blue-600 mb-1">0</p>
            <p className="text-sm text-slate-500">Total assessments</p>
          </div>

          <div className="metric-card text-center">
            <div className="w-12 h-12 bg-gradient-to-r from-amber-500 to-orange-500 rounded-full flex items-center justify-center mx-auto mb-4">
              <span className="text-2xl">🎯</span>
            </div>
            <h3 className="text-lg font-semibold text-slate-800 mb-2">Goals Met</h3>
            <p className="text-3xl font-bold text-amber-600 mb-1">0%</p>
            <p className="text-sm text-slate-500">Reduction targets</p>
          </div>

          <div className="metric-card text-center">
            <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center mx-auto mb-4">
              <span className="text-2xl">🏆</span>
            </div>
            <h3 className="text-lg font-semibold text-slate-800 mb-2">Eco Score</h3>
            <p className="text-3xl font-bold text-purple-600 mb-1">--</p>
            <p className="text-sm text-slate-500">Environmental rating</p>
          </div>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 gap-8 mb-12">
          <div className="card">
            <h3 className="text-2xl font-semibold text-slate-800 mb-6">Quick Actions</h3>
            <div className="space-y-4">
              <button 
                onClick={onNavigateToHome}
                className="w-full text-left p-6 rounded-xl border-2 border-emerald-200 hover:border-emerald-400 hover:bg-emerald-50 transition-all duration-200 group"
              >
                <div className="flex items-center">
                  <div className="w-12 h-12 bg-gradient-to-r from-emerald-500 to-green-500 rounded-full flex items-center justify-center mr-4 group-hover:scale-110 transition-transform">
                    <span className="text-2xl">🧮</span>
                  </div>
                  <div>
                    <h4 className="font-semibold text-slate-800 mb-1">Calculate Carbon Footprint</h4>
                    <p className="text-sm text-slate-600">Track your daily environmental impact</p>
                  </div>
                </div>
              </button>
              
              <div className="p-6 rounded-xl border-2 border-slate-200 opacity-60">
                <div className="flex items-center">
                  <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full flex items-center justify-center mr-4">
                    <span className="text-2xl">📈</span>
                  </div>
                  <div>
                    <h4 className="font-semibold text-slate-800 mb-1">View History</h4>
                    <p className="text-sm text-slate-600">See your carbon footprint trends (Coming Soon)</p>
                  </div>
                </div>
              </div>
              
              <div className="p-6 rounded-xl border-2 border-slate-200 opacity-60">
                <div className="flex items-center">
                  <div className="w-12 h-12 bg-gradient-to-r from-amber-500 to-orange-500 rounded-full flex items-center justify-center mr-4">
                    <span className="text-2xl">🎯</span>
                  </div>
                  <div>
                    <h4 className="font-semibold text-slate-800 mb-1">Set Goals</h4>
                    <p className="text-sm text-slate-600">Define your sustainability targets (Coming Soon)</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="card">
            <h3 className="text-2xl font-semibold text-slate-800 mb-6">Environmental Tips</h3>
            <div className="space-y-4">
              <div className="p-6 bg-gradient-to-r from-emerald-50 to-green-50 rounded-xl border border-emerald-200">
                <h4 className="font-semibold text-emerald-800 mb-2 flex items-center">
                  <span className="mr-2">🚗</span>
                  Transportation
                </h4>
                <p className="text-sm text-emerald-700">
                  Consider walking, cycling, or using public transport for short distances to reduce your carbon footprint.
                </p>
              </div>
              
              <div className="p-6 bg-gradient-to-r from-blue-50 to-cyan-50 rounded-xl border border-blue-200">
                <h4 className="font-semibold text-blue-800 mb-2 flex items-center">
                  <span className="mr-2">⚡</span>
                  Energy Saving
                </h4>
                <p className="text-sm text-blue-700">
                  Switch to LED bulbs and unplug electronics when not in use to reduce energy consumption.
                </p>
              </div>
              
              <div className="p-6 bg-gradient-to-r from-orange-50 to-amber-50 rounded-xl border border-orange-200">
                <h4 className="font-semibold text-orange-800 mb-2 flex items-center">
                  <span className="mr-2">🍃</span>
                  Sustainable Living
                </h4>
                <p className="text-sm text-orange-700">
                  Reduce meat consumption and choose locally sourced foods to lower your dietary carbon footprint.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Call to Action */}
        <div className="card bg-gradient-to-r from-emerald-600 to-green-600 text-white text-center">
          <h3 className="text-3xl font-bold mb-4">Ready to Track Your Impact?</h3>
          <p className="text-emerald-100 mb-6 text-lg max-w-2xl mx-auto">
            Start by calculating your carbon footprint and get personalized recommendations 
            to reduce your environmental impact.
          </p>
          <button 
            onClick={onNavigateToHome}
            className="bg-white text-emerald-600 hover:bg-emerald-50 font-semibold py-4 px-8 rounded-xl transition-all duration-200 shadow-lg hover:shadow-xl transform hover:scale-105"
          >
            Get Started Now
          </button>
        </div>
      </main>
    </div>
  );
};

export default Dashboard;
