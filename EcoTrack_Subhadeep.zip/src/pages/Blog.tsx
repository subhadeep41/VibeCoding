import React, { useState, useEffect } from 'react';
import blogEnvImage from '../assets/blog_env.jpg';

interface BlogProps {
  onNavigateToHome: () => void;
  onNavigateToDashboard?: () => void;
  onNavigateToAnalytics?: () => void;
  onOpenAuthModal?: (mode: 'login' | 'signup') => void;
}

const Blog: React.FC<BlogProps> = ({ onNavigateToHome, onNavigateToDashboard, onNavigateToAnalytics, onOpenAuthModal }) => {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [isNavVisible, setIsNavVisible] = useState(true);
  const [lastScrollY, setLastScrollY] = useState(0);
  const [isAccountDropdownOpen, setIsAccountDropdownOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      const currentScrollY = window.scrollY;
      
      if (currentScrollY < lastScrollY || currentScrollY < 100) {
        // Scrolling up or near top
        setIsNavVisible(true);
      } else {
        // Scrolling down
        setIsNavVisible(false);
      }
      
      setLastScrollY(currentScrollY);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    
    return () => window.removeEventListener('scroll', handleScroll);
  }, [lastScrollY]);

  const blogPosts = [
    {
      id: 1,
      title: "10 Simple Ways to Reduce Your Carbon Footprint Today",
      excerpt: "Discover practical steps you can take right now to minimize your environmental impact and contribute to a sustainable future.",
      category: "lifestyle",
      author: "Sarah Green",
      date: "2025-08-01",
      readTime: "5 min read",
      image: "https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?w=400&h=250&fit=crop&crop=entropy&auto=format",
      featured: true
    },
    {
      id: 2,
      title: "Understanding Carbon Credits: A Complete Guide",
      excerpt: "Learn how carbon credits work, their impact on climate change, and how individuals and businesses can use them effectively.",
      category: "education",
      author: "Dr. Michael Chen",
      date: "2025-07-28",
      readTime: "8 min read",
      image: "https://images.unsplash.com/photo-1569163139394-de4e4f43e4e3?w=400&h=250&fit=crop&crop=entropy&auto=format",
      featured: false
    },
    {
      id: 3,
      title: "The Future of Renewable Energy in 2025",
      excerpt: "Explore the latest innovations in renewable energy technology and how they're reshaping our approach to sustainable living.",
      category: "technology",
      author: "Emma Rodriguez",
      date: "2025-07-25",
      readTime: "6 min read",
      image: "https://images.unsplash.com/photo-1466611653911-95081537e5b7?w=400&h=250&fit=crop&crop=entropy&auto=format",
      featured: true
    },
    {
      id: 4,
      title: "Sustainable Transportation: Electric vs Hybrid",
      excerpt: "Compare electric and hybrid vehicles to make an informed decision about your next eco-friendly car purchase.",
      category: "transportation",
      author: "James Wilson",
      date: "2025-07-22",
      readTime: "7 min read",
      image: "https://images.unsplash.com/photo-1593941707882-a5bac6861d75?w=400&h=250&fit=crop&crop=entropy&auto=format",
      featured: false
    },
    {
      id: 5,
      title: "Building an Eco-Friendly Home: Green Architecture Tips",
      excerpt: "Transform your living space with sustainable design principles that reduce energy consumption and environmental impact.",
      category: "lifestyle",
      author: "Lisa Park",
      date: "2025-07-20",
      readTime: "9 min read",
      image: "https://images.unsplash.com/photo-1518155317743-a8ff43ea6a5f?w=400&h=250&fit=crop&crop=entropy&auto=format",
      featured: false
    },
    {
      id: 6,
      title: "Climate Data Analysis: Trends and Predictions",
      excerpt: "Dive into the latest climate data and scientific predictions about environmental changes in the coming decades.",
      category: "education",
      author: "Dr. Alex Thompson",
      date: "2025-07-18",
      readTime: "10 min read",
      image: "https://images.unsplash.com/photo-1551522435-a13afa10f103?w=400&h=250&fit=crop&crop=entropy&auto=format",
      featured: false
    }
  ];

  const categories = [
    { id: 'all', name: 'All Posts', count: blogPosts.length },
    { id: 'lifestyle', name: 'Lifestyle', count: blogPosts.filter(post => post.category === 'lifestyle').length },
    { id: 'education', name: 'Education', count: blogPosts.filter(post => post.category === 'education').length },
    { id: 'technology', name: 'Technology', count: blogPosts.filter(post => post.category === 'technology').length },
    { id: 'transportation', name: 'Transportation', count: blogPosts.filter(post => post.category === 'transportation').length }
  ];

  const filteredPosts = selectedCategory === 'all' 
    ? blogPosts 
    : blogPosts.filter(post => post.category === selectedCategory);

  const featuredPosts = blogPosts.filter(post => post.featured);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-green-50 to-emerald-50">
      {/* Navigation Bar */}
      <nav className={`fixed top-0 left-0 w-full z-50 bg-white/90 backdrop-blur-md border-b border-slate-200/50 shadow-lg transition-transform duration-300 ease-in-out ${
        isNavVisible ? 'translate-y-0' : '-translate-y-full'
      }`}>
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-r from-emerald-500 to-green-500 rounded-full flex items-center justify-center shadow-lg">
                <span className="text-2xl">🌱</span>
              </div>
              <div className="flex flex-col">
                <span className="text-2xl font-bold bg-gradient-to-r from-emerald-600 to-green-600 bg-clip-text text-transparent">
                  EcoTrack
                </span>
                <span className="text-xs text-slate-500 -mt-1">Carbon Calculator</span>
              </div>
            </div>
            
            {/* Navigation Links */}
            <div className="hidden md:flex items-center space-x-6">
              <button
                onClick={onNavigateToDashboard}
                className="text-slate-600 hover:text-emerald-600 font-medium px-3 py-2 rounded-lg hover:bg-emerald-50 transition-all duration-200"
              >
                Dashboard
              </button>
              <button
                onClick={onNavigateToAnalytics}
                className="text-slate-600 hover:text-emerald-600 font-medium px-3 py-2 rounded-lg hover:bg-emerald-50 transition-all duration-200"
              >
                Analytics
              </button>
              <span className="text-emerald-600 font-semibold px-3 py-2 rounded-lg bg-emerald-50 border border-emerald-200">
                Blog
              </span>
              <button 
                onClick={onNavigateToHome}
                className="bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 text-white font-semibold px-6 py-2.5 rounded-lg transition-all duration-300 shadow-lg hover:shadow-emerald-500/25 transform hover:scale-105 inline-flex items-center gap-2"
              >
                <span>Calculate Your Carbon Footprint</span>
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </button>
            </div>
            
            {/* Account Dropdown */}
            <div className="relative">
              <button 
                onClick={() => setIsAccountDropdownOpen(!isAccountDropdownOpen)}
                className="w-10 h-10 rounded-full bg-gradient-to-br from-emerald-100 to-green-100 flex items-center justify-center border-2 border-emerald-200 shadow-sm hover:shadow-md hover:scale-105 transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:ring-offset-2"
              >
                <svg className="w-5 h-5 text-emerald-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                </svg>
              </button>
              
              {/* Dropdown Menu */}
              {isAccountDropdownOpen && (
                <div className="absolute right-0 mt-2 w-48 bg-white/95 backdrop-blur-md rounded-xl shadow-xl border border-slate-200/50 py-2 z-50 animate-fadeInUp">
                  <button 
                    onClick={() => {
                      setIsAccountDropdownOpen(false);
                      onOpenAuthModal?.('login');
                    }}
                    className="w-full text-left px-4 py-3 text-slate-700 hover:bg-emerald-50 hover:text-emerald-700 transition-colors duration-200 flex items-center gap-3"
                  >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1" />
                    </svg>
                    <span className="font-medium">Login</span>
                  </button>
                  <button 
                    onClick={() => {
                      setIsAccountDropdownOpen(false);
                      onOpenAuthModal?.('signup');
                    }}
                    className="w-full text-left px-4 py-3 text-slate-700 hover:bg-emerald-50 hover:text-emerald-700 transition-colors duration-200 flex items-center gap-3"
                  >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z" />
                    </svg>
                    <span className="font-medium">Create Account</span>
                  </button>
                </div>
              )}
              
              {/* Click outside to close dropdown */}
              {isAccountDropdownOpen && (
                <div 
                  className="fixed inset-0 z-40" 
                  onClick={() => setIsAccountDropdownOpen(false)}
                ></div>
              )}
            </div>
          </div>
        </div>
      </nav>

      {/* Header Section */}
      <div 
        className="pt-24 pb-12 text-white relative bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: `url(${blogEnvImage})` }}
      >
        {/* Dark overlay for text readability */}
        <div className="absolute inset-0 bg-gradient-to-r from-emerald-900/80 to-green-900/80"></div>
        
        <div className="container mx-auto px-6 relative z-10">
          <div className="text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              EcoTrack Blog
            </h1>
            <p className="text-xl text-emerald-100 max-w-2xl mx-auto">
              Insights, tips, and latest trends in sustainable living and carbon footprint reduction
            </p>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-6 py-12">
        {/* Featured Posts Section */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold text-slate-800 mb-8">Featured Articles</h2>
          <div className="grid md:grid-cols-2 gap-8">
            {featuredPosts.map((post) => (
              <article key={post.id} className="card group cursor-pointer hover:scale-[1.02] transition-all duration-300">
                <div className="relative overflow-hidden rounded-xl mb-6">
                  <img 
                    src={post.image} 
                    alt={post.title}
                    className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute top-4 left-4">
                    <span className="badge badge-success capitalize">{post.category}</span>
                  </div>
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-slate-800 mb-3 group-hover:text-emerald-600 transition-colors">
                    {post.title}
                  </h3>
                  <p className="text-slate-600 mb-4 leading-relaxed">
                    {post.excerpt}
                  </p>
                  <div className="flex items-center justify-between text-sm text-slate-500">
                    <div className="flex items-center space-x-4">
                      <span className="font-medium">{post.author}</span>
                      <span>{new Date(post.date).toLocaleDateString('en-US', { 
                        year: 'numeric', 
                        month: 'long', 
                        day: 'numeric' 
                      })}</span>
                    </div>
                    <span className="text-emerald-600 font-medium">{post.readTime}</span>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </section>

        {/* Category Filter */}
        <section className="mb-12">
          <div className="flex flex-wrap gap-3 justify-center">
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => setSelectedCategory(category.id)}
                className={`px-6 py-3 rounded-full font-medium transition-all duration-200 ${
                  selectedCategory === category.id
                    ? 'bg-emerald-600 text-white shadow-lg'
                    : 'bg-white text-slate-600 hover:bg-emerald-50 hover:text-emerald-600 border border-slate-200'
                }`}
              >
                {category.name} ({category.count})
              </button>
            ))}
          </div>
        </section>

        {/* All Posts Grid */}
        <section>
          <h2 className="text-3xl font-bold text-slate-800 mb-8">
            {selectedCategory === 'all' ? 'All Articles' : `${categories.find(c => c.id === selectedCategory)?.name} Articles`}
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredPosts.map((post) => (
              <article key={post.id} className="card group cursor-pointer hover:scale-[1.02] transition-all duration-300">
                <div className="relative overflow-hidden rounded-xl mb-4">
                  <img 
                    src={post.image} 
                    alt={post.title}
                    className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute top-3 left-3">
                    <span className="badge badge-success capitalize text-xs">{post.category}</span>
                  </div>
                </div>
                <div>
                  <h3 className="text-xl font-bold text-slate-800 mb-2 group-hover:text-emerald-600 transition-colors">
                    {post.title}
                  </h3>
                  <p className="text-slate-600 mb-4 text-sm leading-relaxed line-clamp-3">
                    {post.excerpt}
                  </p>
                  <div className="flex items-center justify-between text-xs text-slate-500">
                    <div className="flex flex-col space-y-1">
                      <span className="font-medium">{post.author}</span>
                      <span>{new Date(post.date).toLocaleDateString('en-US', { 
                        month: 'short', 
                        day: 'numeric' 
                      })}</span>
                    </div>
                    <span className="text-emerald-600 font-medium">{post.readTime}</span>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </section>

        {/* Call to Action */}
        <section className="mt-16">
          <div className="card bg-gradient-to-r from-emerald-600 to-green-600 text-white text-center">
            <h3 className="text-3xl font-bold mb-4">Ready to Track Your Impact?</h3>
            <p className="text-emerald-100 mb-6 text-lg max-w-2xl mx-auto">
              Start measuring your carbon footprint and get personalized recommendations 
              based on the insights you've learned from our blog.
            </p>
            <button 
              onClick={onNavigateToHome}
              className="bg-white text-emerald-600 hover:bg-emerald-50 font-semibold py-4 px-8 rounded-xl transition-all duration-200 shadow-lg hover:shadow-xl transform hover:scale-105"
            >
              Calculate Your Carbon Footprint
            </button>
          </div>
        </section>
      </div>
    </div>
  );
};

export default Blog;
