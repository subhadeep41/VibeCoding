import React, { useState, useEffect } from 'react';
import carbonEnvImage from '../assets/carbon_env.jpg';
import ApiStatus from '../components/ApiStatus';
import ApiDocsLink from '../components/ApiDocsLink';
import { useAuth } from '../contexts/AuthContext';

interface DashboardProps {
  onNavigateToHome: () => void;
  onNavigateToBlog?: () => void;
  onNavigateToAnalytics?: () => void;
  onOpenAuthModal?: (mode: 'login' | 'signup') => void;
}

const Dashboard: React.FC<DashboardProps> = ({ onNavigateToHome, onNavigateToBlog, onNavigateToAnalytics, onOpenAuthModal }) => {
  const [isNavVisible, setIsNavVisible] = useState(true);
  const [lastScrollY, setLastScrollY] = useState(0);
  const [isAccountDropdownOpen, setIsAccountDropdownOpen] = useState(false);
  const { user, isAuthenticated, logout } = useAuth();

  useEffect(() => {
    const handleScroll = () => {
      const currentScrollY = window.scrollY;
      
      if (currentScrollY < lastScrollY || currentScrollY < 100) {
        // Scrolling up or near top
        setIsNavVisible(true);
      } else {
        // Scrolling down
        setIsNavVisible(false);
      }
      
      setLastScrollY(currentScrollY);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    
    return () => window.removeEventListener('scroll', handleScroll);
  }, [lastScrollY]);

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation Bar */}
      <nav className={`fixed top-0 left-0 w-full z-50 bg-white/90 backdrop-blur-md border-b border-slate-200/50 shadow-lg transition-transform duration-300 ease-in-out ${
        isNavVisible ? 'translate-y-0' : '-translate-y-full'
      }`}>
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-r from-emerald-500 to-green-500 rounded-full flex items-center justify-center shadow-lg">
                <span className="text-2xl">🌱</span>
              </div>
              <div className="flex flex-col">
                <span className="text-2xl font-bold bg-gradient-to-r from-emerald-600 to-green-600 bg-clip-text text-transparent">
                  EcoTrack
                </span>
                <span className="text-xs text-slate-500 -mt-1">Carbon Calculator</span>
              </div>
            </div>
            
            {/* Navigation Links */}
            <div className="hidden md:flex items-center space-x-6">
              <a href="#" className="text-emerald-600 font-semibold px-3 py-2 rounded-lg bg-emerald-50 border border-emerald-200">
                Dashboard
              </a>
              <button
                onClick={onNavigateToAnalytics}
                className="text-slate-600 hover:text-emerald-600 font-medium px-3 py-2 rounded-lg hover:bg-emerald-50 transition-all duration-200"
              >
                Analytics
              </button>
              <button 
                onClick={onNavigateToBlog}
                className="text-slate-600 hover:text-emerald-600 font-medium px-3 py-2 rounded-lg hover:bg-emerald-50 transition-all duration-200"
              >
                Blog
              </button>
              <button 
                onClick={onNavigateToHome}
                className="bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 text-white font-semibold px-6 py-2.5 rounded-lg transition-all duration-300 shadow-lg hover:shadow-emerald-500/25 transform hover:scale-105 inline-flex items-center gap-2"
              >
                <span>Calculate Your Carbon Footprint</span>
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </button>
            </div>
            
            {/* API Status and Account Section */}
            <div className="flex items-center gap-4">
              <ApiDocsLink />
              <ApiStatus />
              
              {/* Account Dropdown */}
              <div className="relative">
              <button 
                onClick={() => setIsAccountDropdownOpen(!isAccountDropdownOpen)}
                className="w-10 h-10 rounded-full bg-gradient-to-br from-emerald-100 to-green-100 flex items-center justify-center border-2 border-emerald-200 shadow-sm hover:shadow-md hover:scale-105 transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:ring-offset-2"
              >
                <svg className="w-5 h-5 text-emerald-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                </svg>
              </button>
              
              {/* Dropdown Menu */}
              {isAccountDropdownOpen && (
                <div className="absolute right-0 mt-2 w-48 bg-white/95 backdrop-blur-md rounded-xl shadow-xl border border-slate-200/50 py-2 z-50 animate-fadeInUp">
                  {isAuthenticated && user ? (
                    // Logged in user menu
                    <>
                      <div className="px-4 py-3 border-b border-slate-200/50">
                        <p className="text-sm font-medium text-slate-900">{user.name}</p>
                        <p className="text-xs text-slate-500">{user.email}</p>
                      </div>
                      <button 
                        onClick={() => {
                          setIsAccountDropdownOpen(false);
                          // Add profile/settings functionality here if needed
                        }}
                        className="w-full text-left px-4 py-3 text-slate-700 hover:bg-emerald-50 hover:text-emerald-700 transition-colors duration-200 flex items-center gap-3"
                      >
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                        </svg>
                        <span className="font-medium">Profile</span>
                      </button>
                      <button 
                        onClick={() => {
                          setIsAccountDropdownOpen(false);
                          logout();
                        }}
                        className="w-full text-left px-4 py-3 text-slate-700 hover:bg-red-50 hover:text-red-700 transition-colors duration-200 flex items-center gap-3"
                      >
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
                        </svg>
                        <span className="font-medium">Logout</span>
                      </button>
                    </>
                  ) : (
                    // Guest user menu
                    <>
                      <button 
                        onClick={() => {
                          setIsAccountDropdownOpen(false);
                          onOpenAuthModal?.('login');
                        }}
                        className="w-full text-left px-4 py-3 text-slate-700 hover:bg-emerald-50 hover:text-emerald-700 transition-colors duration-200 flex items-center gap-3"
                      >
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1" />
                        </svg>
                        <span className="font-medium">Login</span>
                      </button>
                      <button 
                        onClick={() => {
                          setIsAccountDropdownOpen(false);
                          onOpenAuthModal?.('signup');
                        }}
                        className="w-full text-left px-4 py-3 text-slate-700 hover:bg-emerald-50 hover:text-emerald-700 transition-colors duration-200 flex items-center gap-3"
                      >
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z" />
                        </svg>
                        <span className="font-medium">Create Account</span>
                      </button>
                    </>
                  )}
                </div>
              )}
              
              {/* Click outside to close dropdown */}
              {isAccountDropdownOpen && (
                <div 
                  className="fixed inset-0 z-40" 
                  onClick={() => setIsAccountDropdownOpen(false)}
                ></div>
              )}
              </div>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section - positioned to start right below nav */}
      <section className="relative h-screen max-h-screen bg-gradient-to-br from-emerald-50 via-green-50 to-cyan-50 overflow-hidden pt-20">
          {/* Animated Background Elements */}
          <div className="absolute inset-0 overflow-hidden">
            {/* Floating Orbs */}
            <div className="absolute top-20 left-20 w-64 h-64 bg-gradient-to-r from-emerald-300/30 to-green-300/30 rounded-full blur-3xl animate-pulse"></div>
            <div className="absolute bottom-20 right-20 w-72 h-72 bg-gradient-to-r from-cyan-300/30 to-blue-300/30 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '2s' }}></div>
            <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-60 h-60 bg-gradient-to-r from-green-200/20 to-emerald-200/20 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }}></div>
            
            {/* Floating Particles */}
            <div className="absolute top-1/4 left-1/4 w-2 h-2 bg-emerald-400 rounded-full animate-ping opacity-60"></div>
            <div className="absolute top-3/4 left-1/3 w-1 h-1 bg-green-400 rounded-full animate-ping opacity-50" style={{ animationDelay: '3s' }}></div>
            <div className="absolute top-1/3 right-1/4 w-3 h-3 bg-cyan-400 rounded-full animate-ping opacity-40" style={{ animationDelay: '1.5s' }}></div>
            <div className="absolute bottom-1/3 right-1/3 w-2 h-2 bg-blue-400 rounded-full animate-ping opacity-60" style={{ animationDelay: '4s' }}></div>
          </div>

          <div className="relative container mx-auto px-6 py-4 h-full flex items-center">
            <div className="grid lg:grid-cols-2 gap-8 items-center w-full">
              {/* Left Content */}
              <div className="text-left space-y-6">
                {/* Badge */}
                <div className="inline-flex items-center px-4 py-2 bg-white/80 backdrop-blur-md rounded-full border border-emerald-200/50 shadow-lg">
                  <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse mr-3"></div>
                  <span className="text-sm font-medium text-emerald-700">AI-Powered Carbon Tracking</span>
                </div>

                <div className="space-y-4">
                  <h1 className="text-3xl lg:text-5xl xl:text-6xl font-bold text-slate-800 leading-tight">
                    <span className="inline-block animate-fadeInUp">Transform Your Impact,</span>
                    <span className="block bg-gradient-to-r from-emerald-600 via-green-600 to-cyan-600 bg-clip-text text-transparent animate-fadeInUp" style={{ animationDelay: '0.2s' }}>
                      Save Our Planet
                    </span>
                  </h1>
                  
                  <p className="text-lg lg:text-xl xl:text-2xl text-slate-600 leading-relaxed font-medium animate-fadeInUp" style={{ animationDelay: '0.4s' }}>
                    Master your carbon footprint with intelligent tracking and 
                    <span className="bg-gradient-to-r from-emerald-600 to-green-600 bg-clip-text text-transparent font-semibold"> actionable insights</span>
                  </p>
                </div>
                
                {/* Enhanced Stats Indicators */}
                <div className="flex flex-col sm:flex-row sm:space-x-6 space-y-2 sm:space-y-0 animate-fadeInUp" style={{ animationDelay: '0.6s' }}>
                  <div className="flex items-center space-x-3 group">
                    <div className="relative">
                      <div className="w-3 h-3 bg-emerald-500 rounded-full animate-pulse shadow-lg group-hover:scale-110 transition-transform"></div>
                      <div className="absolute inset-0 w-3 h-3 bg-emerald-500 rounded-full animate-ping opacity-30"></div>
                    </div>
                    <span className="text-sm text-slate-700 font-medium group-hover:text-emerald-600 transition-colors">Real-time calculations</span>
                  </div>
                  <div className="flex items-center space-x-3 group">
                    <div className="relative">
                      <div className="w-3 h-3 bg-blue-500 rounded-full animate-pulse shadow-lg group-hover:scale-110 transition-transform" style={{ animationDelay: '1s' }}></div>
                      <div className="absolute inset-0 w-3 h-3 bg-blue-500 rounded-full animate-ping opacity-30" style={{ animationDelay: '1s' }}></div>
                    </div>
                    <span className="text-sm text-slate-700 font-medium group-hover:text-blue-600 transition-colors">Personalized insights</span>
                  </div>
                  <div className="flex items-center space-x-3 group">
                    <div className="relative">
                      <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse shadow-lg group-hover:scale-110 transition-transform" style={{ animationDelay: '2s' }}></div>
                      <div className="absolute inset-0 w-3 h-3 bg-green-500 rounded-full animate-ping opacity-30" style={{ animationDelay: '2s' }}></div>
                    </div>
                    <span className="text-sm text-slate-700 font-medium group-hover:text-green-600 transition-colors">Expert recommendations</span>
                  </div>
                </div>
              </div>
              
              {/* Right Image - Enhanced */}
              <div className="relative animate-fadeInUp" style={{ animationDelay: '0.8s' }}>
                {/* Decorative Elements */}
                <div className="absolute -top-4 -left-4 w-24 h-24 bg-gradient-to-br from-emerald-400/20 to-green-400/20 rounded-full blur-2xl animate-pulse"></div>
                <div className="absolute -bottom-4 -right-4 w-32 h-32 bg-gradient-to-br from-cyan-400/20 to-blue-400/20 rounded-full blur-2xl animate-pulse" style={{ animationDelay: '1s' }}></div>
                
                <div className="relative overflow-hidden rounded-3xl shadow-2xl bg-white/10 backdrop-blur-md border border-white/20 hover:shadow-3xl transition-all duration-500 group">
                  <img 
                    src={carbonEnvImage} 
                    alt="Environmental carbon tracking visualization" 
                    className="w-full h-[350px] object-cover group-hover:scale-105 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-tr from-emerald-500/20 via-green-500/10 to-cyan-500/20 rounded-3xl"></div>
                  
                  {/* Enhanced Floating Elements */}
                  <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-md rounded-xl px-3 py-2 shadow-xl border border-white/30 hover:scale-105 transition-transform">
                    <div className="flex items-center space-x-2">
                      <div className="relative">
                        <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                        <div className="absolute inset-0 w-2 h-2 bg-green-500 rounded-full animate-ping opacity-40"></div>
                      </div>
                      <div>
                        <span className="text-xs font-semibold text-slate-700">Live Tracking</span>
                        <div className="text-xs text-green-600 font-medium">Active</div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="absolute bottom-4 left-4 bg-white/90 backdrop-blur-md rounded-xl px-3 py-2 shadow-xl border border-white/30 hover:scale-105 transition-transform">
                    <div className="text-xs text-slate-600 font-medium">Carbon Reduced</div>
                    <div className="text-lg font-bold text-emerald-600">15.2 kg</div>
                    <div className="text-xs text-slate-500">This month • +12%</div>
                  </div>

                  <div className="absolute top-1/2 -right-3 bg-gradient-to-r from-emerald-500 to-green-500 text-white rounded-full px-3 py-1 shadow-lg transform rotate-12 hover:rotate-6 transition-transform">
                    <div className="text-xs font-bold">Climate Hero</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Main Content */}
        <main className="container mx-auto px-6 py-16 -mt-10 relative z-10">
          {/* Welcome Card */}
          <div className="card mb-12">
            <div className="text-center">
              <h2 className="text-3xl font-bold text-slate-800 mb-4">
                Welcome to Your Environmental Dashboard
              </h2>
              <p className="text-lg text-slate-600 max-w-3xl mx-auto">
                Track, understand, and reduce your carbon footprint with our comprehensive suite of tools. 
                Get personalized insights and actionable recommendations to make a real difference.
              </p>
            </div>
          </div>

          {/* Stats Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
            <div className="metric-card text-center">
              <div className="w-12 h-12 bg-gradient-to-r from-emerald-500 to-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl">🌱</span>
              </div>
              <h3 className="text-lg font-semibold text-slate-800 mb-2">Carbon Saved</h3>
              <p className="text-3xl font-bold text-emerald-600 mb-1">0 kg CO₂</p>
              <p className="text-sm text-slate-500">This month</p>
            </div>

            <div className="metric-card text-center">
              <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl">📊</span>
              </div>
              <h3 className="text-lg font-semibold text-slate-800 mb-2">Calculations</h3>
              <p className="text-3xl font-bold text-blue-600 mb-1">0</p>
              <p className="text-sm text-slate-500">Total assessments</p>
            </div>

            <div className="metric-card text-center">
              <div className="w-12 h-12 bg-gradient-to-r from-amber-500 to-orange-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl">🎯</span>
              </div>
              <h3 className="text-lg font-semibold text-slate-800 mb-2">Goals Met</h3>
              <p className="text-3xl font-bold text-amber-600 mb-1">0%</p>
              <p className="text-sm text-slate-500">Reduction targets</p>
            </div>

            <div className="metric-card text-center">
              <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl">🏆</span>
              </div>
              <h3 className="text-lg font-semibold text-slate-800 mb-2">Eco Score</h3>
              <p className="text-3xl font-bold text-purple-600 mb-1">--</p>
              <p className="text-sm text-slate-500">Environmental rating</p>
            </div>
          </div>

          {/* Features Grid */}
          <div className="grid md:grid-cols-2 gap-8 mb-12">
            <div className="card">
              <h3 className="text-2xl font-semibold text-slate-800 mb-6">Quick Actions</h3>
              <div className="space-y-4">
                <button 
                  onClick={onNavigateToHome}
                  className="w-full text-left p-6 rounded-xl border-2 border-emerald-200 hover:border-emerald-400 hover:bg-emerald-50 transition-all duration-200 group"
                >
                  <div className="flex items-center">
                    <div className="w-12 h-12 bg-gradient-to-r from-emerald-500 to-green-500 rounded-full flex items-center justify-center mr-4 group-hover:scale-110 transition-transform">
                      <span className="text-2xl">🧮</span>
                    </div>
                    <div>
                      <h4 className="font-semibold text-slate-800 mb-1">Calculate Carbon Footprint</h4>
                      <p className="text-sm text-slate-600">Track your daily environmental impact</p>
                    </div>
                  </div>
                </button>
                
                <div className="p-6 rounded-xl border-2 border-slate-200 opacity-60">
                  <div className="flex items-center">
                    <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full flex items-center justify-center mr-4">
                      <span className="text-2xl">📈</span>
                    </div>
                    <div>
                      <h4 className="font-semibold text-slate-800 mb-1">View History</h4>
                      <p className="text-sm text-slate-600">See your carbon footprint trends (Coming Soon)</p>
                    </div>
                  </div>
                </div>
                
                <div className="p-6 rounded-xl border-2 border-slate-200 opacity-60">
                  <div className="flex items-center">
                    <div className="w-12 h-12 bg-gradient-to-r from-amber-500 to-orange-500 rounded-full flex items-center justify-center mr-4">
                      <span className="text-2xl">🎯</span>
                    </div>
                    <div>
                      <h4 className="font-semibold text-slate-800 mb-1">Set Goals</h4>
                      <p className="text-sm text-slate-600">Define your sustainability targets (Coming Soon)</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="card">
              <h3 className="text-2xl font-semibold text-slate-800 mb-6">Environmental Tips</h3>
              <div className="space-y-4">
                <div className="p-6 bg-gradient-to-r from-emerald-50 to-green-50 rounded-xl border border-emerald-200">
                  <h4 className="font-semibold text-emerald-800 mb-2 flex items-center">
                    <span className="mr-2">🚗</span>
                    Transportation
                  </h4>
                  <p className="text-sm text-emerald-700">
                    Consider walking, cycling, or using public transport for short distances to reduce your carbon footprint.
                  </p>
                </div>
                
                <div className="p-6 bg-gradient-to-r from-blue-50 to-cyan-50 rounded-xl border border-blue-200">
                  <h4 className="font-semibold text-blue-800 mb-2 flex items-center">
                    <span className="mr-2">⚡</span>
                    Energy Saving
                  </h4>
                  <p className="text-sm text-blue-700">
                    Switch to LED bulbs and unplug electronics when not in use to reduce energy consumption.
                  </p>
                </div>
                
                <div className="p-6 bg-gradient-to-r from-orange-50 to-amber-50 rounded-xl border border-orange-200">
                  <h4 className="font-semibold text-orange-800 mb-2 flex items-center">
                    <span className="mr-2">🍃</span>
                    Sustainable Living
                  </h4>
                  <p className="text-sm text-orange-700">
                    Reduce meat consumption and choose locally sourced foods to lower your dietary carbon footprint.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Call to Action */}
          <div className="card bg-gradient-to-r from-emerald-600 to-green-600 text-white text-center">
            <h3 className="text-3xl font-bold mb-4">Ready to Track Your Impact?</h3>
            <p className="text-emerald-100 mb-6 text-lg max-w-2xl mx-auto">
              Start by calculating your carbon footprint and get personalized recommendations 
              to reduce your environmental impact.
            </p>
            <button 
              onClick={onNavigateToHome}
              className="bg-white text-emerald-600 hover:bg-emerald-50 font-semibold py-4 px-8 rounded-xl transition-all duration-200 shadow-lg hover:shadow-xl transform hover:scale-105"
            >
              Get Started Now
            </button>
          </div>
        </main>
    </div>
  );
};

export default Dashboard;
