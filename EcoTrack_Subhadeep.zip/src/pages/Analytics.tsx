import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import ApiStatus from '../components/ApiStatus';
import ApiDocsLink from '../components/ApiDocsLink';

interface AnalyticsProps {
  onNavigateToHome: () => void;
  onNavigateToDashboard: () => void;
  onNavigateToBlog?: () => void;
  onOpenAuthModal?: (mode: 'login' | 'signup') => void;
}

// Mock data for analytics - in a real app, this would come from an API
const mockAnalyticsData = {
  monthlyEmissions: [
    { month: 'Jan', emissions: 2.8, target: 2.5 },
    { month: 'Feb', emissions: 2.6, target: 2.5 },
    { month: 'Mar', emissions: 2.9, target: 2.5 },
    { month: 'Apr', emissions: 2.4, target: 2.5 },
    { month: 'May', emissions: 2.2, target: 2.5 },
    { month: 'Jun', emissions: 2.1, target: 2.5 },
  ],
  categories: [
    { name: 'Transportation', percentage: 45, emissions: 1.2, color: 'bg-red-500' },
    { name: 'Energy', percentage: 35, emissions: 0.9, color: 'bg-orange-500' },
    { name: 'Food', percentage: 20, emissions: 0.5, color: 'bg-green-500' },
  ],
  yearlyComparison: {
    thisYear: 28.5,
    lastYear: 32.1,
    improvement: 11.2
  },
  globalStats: {
    globalAverage: 4.8,
    userEmissions: 2.4,
    ranking: 15, // percentile
  }
};

const Analytics: React.FC<AnalyticsProps> = ({ 
  onNavigateToHome, 
  onNavigateToDashboard, 
  onNavigateToBlog, 
  onOpenAuthModal 
}) => {
  const [isNavVisible, setIsNavVisible] = useState(true);
  const [lastScrollY, setLastScrollY] = useState(0);
  const [isAccountDropdownOpen, setIsAccountDropdownOpen] = useState(false);
  const [selectedTimeframe, setSelectedTimeframe] = useState<'6months' | '1year' | '2years'>('6months');
  const { user, isAuthenticated, logout } = useAuth();

  useEffect(() => {
    const handleScroll = () => {
      const currentScrollY = window.scrollY;
      
      if (currentScrollY < lastScrollY || currentScrollY < 100) {
        setIsNavVisible(true);
      } else {
        setIsNavVisible(false);
      }
      
      setLastScrollY(currentScrollY);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    
    return () => window.removeEventListener('scroll', handleScroll);
  }, [lastScrollY]);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation Bar */}
      <nav className={`fixed top-0 left-0 w-full z-50 bg-white/90 backdrop-blur-md border-b border-slate-200/50 shadow-lg transition-transform duration-300 ease-in-out ${
        isNavVisible ? 'translate-y-0' : '-translate-y-full'
      }`}>
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-r from-emerald-500 to-green-500 rounded-full flex items-center justify-center shadow-lg">
                <span className="text-2xl">🌱</span>
              </div>
              <div className="flex flex-col">
                <span className="text-2xl font-bold bg-gradient-to-r from-emerald-600 to-green-600 bg-clip-text text-transparent">
                  EcoTrack
                </span>
                <span className="text-xs text-slate-500 -mt-1">Analytics Dashboard</span>
              </div>
            </div>
            
            {/* Navigation Links */}
            <div className="hidden md:flex items-center space-x-6">
              <button
                onClick={onNavigateToDashboard}
                className="text-slate-600 hover:text-emerald-600 font-medium px-3 py-2 rounded-lg hover:bg-emerald-50 transition-all duration-200"
              >
                Dashboard
              </button>
              <span className="text-emerald-600 font-semibold px-3 py-2 rounded-lg bg-emerald-50 border border-emerald-200">
                Analytics
              </span>
              <button 
                onClick={onNavigateToBlog}
                className="text-slate-600 hover:text-emerald-600 font-medium px-3 py-2 rounded-lg hover:bg-emerald-50 transition-all duration-200"
              >
                Blog
              </button>
              <button
                onClick={onNavigateToHome}
                className="text-slate-600 hover:text-emerald-600 font-medium px-3 py-2 rounded-lg hover:bg-emerald-50 transition-all duration-200"
              >
                Calculator
              </button>
            </div>
            
            {/* API Status and Account Section */}
            <div className="flex items-center gap-4">
              <ApiDocsLink />
              <ApiStatus />
              
              {/* Account Dropdown */}
              <div className="relative">
                <button 
                  onClick={() => setIsAccountDropdownOpen(!isAccountDropdownOpen)}
                  className="w-10 h-10 rounded-full bg-gradient-to-br from-emerald-100 to-green-100 flex items-center justify-center border-2 border-emerald-200 shadow-sm hover:shadow-md hover:scale-105 transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:ring-offset-2"
                >
                  <svg className="w-5 h-5 text-emerald-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                  </svg>
                </button>
                
                {/* Dropdown Menu */}
                {isAccountDropdownOpen && (
                  <div className="absolute right-0 mt-2 w-56 bg-white/95 backdrop-blur-md rounded-xl shadow-xl border border-slate-200/50 py-2 z-50 animate-fadeInUp">
                    {isAuthenticated && user ? (
                      <>
                        <div className="px-4 py-3 border-b border-slate-200/50">
                          <div className="text-sm font-medium text-emerald-700 truncate">
                            {user.name}
                          </div>
                          <div className="text-xs text-slate-500 truncate">
                            {user.email}
                          </div>
                        </div>
                        <button 
                          onClick={() => {
                            setIsAccountDropdownOpen(false);
                            logout();
                          }}
                          className="w-full text-left px-4 py-3 text-slate-700 hover:bg-red-50 hover:text-red-700 transition-colors duration-200 flex items-center gap-3"
                        >
                          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
                          </svg>
                          <span className="font-medium">Logout</span>
                        </button>
                      </>
                    ) : (
                      <>
                        <button 
                          onClick={() => {
                            setIsAccountDropdownOpen(false);
                            onOpenAuthModal?.('login');
                          }}
                          className="w-full text-left px-4 py-3 text-slate-700 hover:bg-emerald-50 hover:text-emerald-700 transition-colors duration-200 flex items-center gap-3"
                        >
                          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1" />
                          </svg>
                          <span className="font-medium">Login</span>
                        </button>
                        <button 
                          onClick={() => {
                            setIsAccountDropdownOpen(false);
                            onOpenAuthModal?.('signup');
                          }}
                          className="w-full text-left px-4 py-3 text-slate-700 hover:bg-emerald-50 hover:text-emerald-700 transition-colors duration-200 flex items-center gap-3"
                        >
                          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z" />
                          </svg>
                          <span className="font-medium">Create Account</span>
                        </button>
                      </>
                    )}
                  </div>
                )}
                
                {/* Click outside to close dropdown */}
                {isAccountDropdownOpen && (
                  <div 
                    className="fixed inset-0 z-40" 
                    onClick={() => setIsAccountDropdownOpen(false)}
                  ></div>
                )}
              </div>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <div className="pt-20 pb-12">
        <div className="max-w-7xl mx-auto px-6">
          {/* Header */}
          <div className="mb-8">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-4xl font-bold text-slate-800 mb-2">Carbon Analytics</h1>
                <p className="text-slate-600">Track your environmental impact over time</p>
              </div>
              
              {/* Timeframe Selector */}
              <div className="flex bg-white rounded-lg border border-slate-200 p-1">
                {[
                  { key: '6months', label: '6M' },
                  { key: '1year', label: '1Y' },
                  { key: '2years', label: '2Y' }
                ].map((option) => (
                  <button
                    key={option.key}
                    onClick={() => setSelectedTimeframe(option.key as any)}
                    className={`px-4 py-2 rounded-md text-sm font-medium transition-all duration-200 ${
                      selectedTimeframe === option.key
                        ? 'bg-emerald-100 text-emerald-700 shadow-sm'
                        : 'text-slate-600 hover:text-slate-800'
                    }`}
                  >
                    {option.label}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Key Metrics Row */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            {/* Current Month */}
            <div className="bg-white/90 backdrop-blur-sm rounded-xl p-6 border border-slate-200/50 shadow-lg">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-sm font-semibold text-slate-600">This Month</h3>
                <div className="w-8 h-8 bg-emerald-100 rounded-full flex items-center justify-center">
                  <svg className="w-4 h-4 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
                  </svg>
                </div>
              </div>
              <div className="text-2xl font-bold text-slate-800 mb-1">2.1 tons</div>
              <div className="text-sm text-emerald-600 font-medium">↓ 12% from last month</div>
            </div>

            {/* Yearly Total */}
            <div className="bg-white/90 backdrop-blur-sm rounded-xl p-6 border border-slate-200/50 shadow-lg">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-sm font-semibold text-slate-600">This Year</h3>
                <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                  <svg className="w-4 h-4 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                  </svg>
                </div>
              </div>
              <div className="text-2xl font-bold text-slate-800 mb-1">28.5 tons</div>
              <div className="text-sm text-emerald-600 font-medium">↓ 11.2% from last year</div>
            </div>

            {/* Global Ranking */}
            <div className="bg-white/90 backdrop-blur-sm rounded-xl p-6 border border-slate-200/50 shadow-lg">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-sm font-semibold text-slate-600">Global Ranking</h3>
                <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
                  <svg className="w-4 h-4 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                  </svg>
                </div>
              </div>
              <div className="text-2xl font-bold text-slate-800 mb-1">Top 15%</div>
              <div className="text-sm text-emerald-600 font-medium">Better than 85% of users</div>
            </div>

            {/* Target Progress */}
            <div className="bg-white/90 backdrop-blur-sm rounded-xl p-6 border border-slate-200/50 shadow-lg">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-sm font-semibold text-slate-600">Target Progress</h3>
                <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                  <svg className="w-4 h-4 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
              </div>
              <div className="text-2xl font-bold text-slate-800 mb-1">84%</div>
              <div className="text-sm text-emerald-600 font-medium">On track for yearly goal</div>
            </div>
          </div>

          {/* Calculation Methodology Section */}
          <div className="bg-white/90 backdrop-blur-sm rounded-xl p-8 border border-slate-200/50 shadow-lg mb-8">
            <div className="flex items-center mb-8">
              <div className="w-12 h-12 bg-gradient-to-r from-blue-100 to-indigo-100 rounded-xl flex items-center justify-center mr-4">
                <svg className="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
                </svg>
              </div>
              <div>
                <h2 className="text-2xl font-bold text-slate-800">Calculation Methodology</h2>
                <p className="text-slate-600">Understanding how your carbon footprint is calculated</p>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Transportation Calculations */}
              <div className="space-y-6">
                <div className="p-6 bg-red-50 rounded-xl border border-red-200">
                  <div className="flex items-center mb-4">
                    <div className="w-10 h-10 bg-red-100 rounded-full flex items-center justify-center mr-3">
                      <svg className="w-5 h-5 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                    </div>
                    <h3 className="text-lg font-semibold text-red-800">Transportation</h3>
                  </div>
                  
                  <div className="space-y-4 text-sm">
                    <div>
                      <h4 className="font-semibold text-red-700 mb-2">Formula:</h4>
                      <div className="bg-white/70 p-3 rounded-lg font-mono text-xs">
                        CO₂ = Distance × Emission Factor
                      </div>
                    </div>
                    
                    <div>
                      <h4 className="font-semibold text-red-700 mb-2">Emission Factors:</h4>
                      <div className="space-y-1 text-xs">
                        <div className="flex justify-between">
                          <span>Car (Petrol):</span>
                          <span className="font-mono">0.21 kg CO₂/km</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Car (Diesel):</span>
                          <span className="font-mono">0.17 kg CO₂/km</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Electric Car:</span>
                          <span className="font-mono">0.05 kg CO₂/km</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Public Transport:</span>
                          <span className="font-mono">0.06 kg CO₂/km</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Bicycle/Walking:</span>
                          <span className="font-mono">0.00 kg CO₂/km</span>
                        </div>
                      </div>
                    </div>
                    
                    <div>
                      <h4 className="font-semibold text-red-700 mb-2">Example:</h4>
                      <div className="bg-white/70 p-3 rounded-lg text-xs">
                        <div>Daily commute: 20 km</div>
                        <div>Car (Petrol): 20 × 0.21 = 4.2 kg CO₂/day</div>
                        <div>Monthly: 4.2 × 30 = 126 kg CO₂</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Energy Calculations */}
              <div className="space-y-6">
                <div className="p-6 bg-orange-50 rounded-xl border border-orange-200">
                  <div className="flex items-center mb-4">
                    <div className="w-10 h-10 bg-orange-100 rounded-full flex items-center justify-center mr-3">
                      <svg className="w-5 h-5 text-orange-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                      </svg>
                    </div>
                    <h3 className="text-lg font-semibold text-orange-800">Energy Usage</h3>
                  </div>
                  
                  <div className="space-y-4 text-sm">
                    <div>
                      <h4 className="font-semibold text-orange-700 mb-2">Formula:</h4>
                      <div className="bg-white/70 p-3 rounded-lg font-mono text-xs">
                        CO₂ = kWh × Grid Factor
                      </div>
                    </div>
                    
                    <div>
                      <h4 className="font-semibold text-orange-700 mb-2">Grid Factors (by Region):</h4>
                      <div className="space-y-1 text-xs">
                        <div className="flex justify-between">
                          <span>Global Average:</span>
                          <span className="font-mono">0.475 kg CO₂/kWh</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Coal Heavy:</span>
                          <span className="font-mono">0.820 kg CO₂/kWh</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Mixed Sources:</span>
                          <span className="font-mono">0.350 kg CO₂/kWh</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Renewable Heavy:</span>
                          <span className="font-mono">0.150 kg CO₂/kWh</span>
                        </div>
                      </div>
                    </div>
                    
                    <div>
                      <h4 className="font-semibold text-orange-700 mb-2">Example:</h4>
                      <div className="bg-white/70 p-3 rounded-lg text-xs">
                        <div>Monthly usage: 300 kWh</div>
                        <div>Grid (Mixed): 300 × 0.35 = 105 kg CO₂</div>
                        <div>Annual: 105 × 12 = 1,260 kg CO₂</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Food Calculations */}
              <div className="space-y-6">
                <div className="p-6 bg-green-50 rounded-xl border border-green-200">
                  <div className="flex items-center mb-4">
                    <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center mr-3">
                      <svg className="w-5 h-5 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                      </svg>
                    </div>
                    <h3 className="text-lg font-semibold text-green-800">Food Choices</h3>
                  </div>
                  
                  <div className="space-y-4 text-sm">
                    <div>
                      <h4 className="font-semibold text-green-700 mb-2">Annual Emissions:</h4>
                      <div className="space-y-1 text-xs">
                        <div className="flex justify-between">
                          <span>High Meat:</span>
                          <span className="font-mono">2,500 kg CO₂/year</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Medium Meat:</span>
                          <span className="font-mono">1,900 kg CO₂/year</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Low Meat:</span>
                          <span className="font-mono">1,500 kg CO₂/year</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Vegetarian:</span>
                          <span className="font-mono">1,200 kg CO₂/year</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Vegan:</span>
                          <span className="font-mono">800 kg CO₂/year</span>
                        </div>
                      </div>
                    </div>
                    
                    <div>
                      <h4 className="font-semibold text-green-700 mb-2">Key Factors:</h4>
                      <div className="space-y-1 text-xs text-green-600">
                        <div>• Livestock methane emissions</div>
                        <div>• Feed production & transport</div>
                        <div>• Food processing & packaging</div>
                        <div>• Refrigeration & storage</div>
                        <div>• Food waste decomposition</div>
                      </div>
                    </div>
                    
                    <div>
                      <h4 className="font-semibold text-green-700 mb-2">Example:</h4>
                      <div className="bg-white/70 p-3 rounded-lg text-xs">
                        <div>Diet: Medium Meat</div>
                        <div>Annual: 1,900 kg CO₂</div>
                        <div>Monthly: 158 kg CO₂</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Additional Information */}
            <div className="mt-8 pt-8 border-t border-slate-200">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                  <h3 className="text-lg font-semibold text-slate-800 mb-4">Data Sources & Standards</h3>
                  <div className="space-y-3 text-sm text-slate-600">
                    <div className="flex items-start space-x-3">
                      <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 flex-shrink-0"></div>
                      <div>
                        <strong>Transportation:</strong> Based on DEFRA UK Government emission factors and EPA guidelines
                      </div>
                    </div>
                    <div className="flex items-start space-x-3">
                      <div className="w-2 h-2 bg-orange-500 rounded-full mt-2 flex-shrink-0"></div>
                      <div>
                        <strong>Energy:</strong> IEA (International Energy Agency) grid emission factors by country/region
                      </div>
                    </div>
                    <div className="flex items-start space-x-3">
                      <div className="w-2 h-2 bg-green-500 rounded-full mt-2 flex-shrink-0"></div>
                      <div>
                        <strong>Food:</strong> Life Cycle Assessment data from research institutions and FAO reports
                      </div>
                    </div>
                  </div>
                </div>
                
                <div>
                  <h3 className="text-lg font-semibold text-slate-800 mb-4">Accuracy & Limitations</h3>
                  <div className="space-y-3 text-sm text-slate-600">
                    <div className="p-4 bg-amber-50 rounded-lg border border-amber-200">
                      <div className="flex items-start space-x-3">
                        <svg className="w-5 h-5 text-amber-600 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z" />
                        </svg>
                        <div>
                          <div className="font-medium text-amber-800 mb-1">Estimation Notice</div>
                          <div className="text-amber-700">Calculations provide estimates based on average values. Individual results may vary based on specific circumstances, equipment efficiency, and regional factors.</div>
                        </div>
                      </div>
                    </div>
                    <div className="text-xs text-slate-500">
                      Last updated: {new Date().toLocaleDateString()}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Charts Row */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
            {/* Monthly Emissions Trend */}
            <div className="bg-white/90 backdrop-blur-sm rounded-xl p-6 border border-slate-200/50 shadow-lg">
              <h3 className="text-lg font-semibold text-slate-800 mb-6">Monthly Emissions Trend</h3>
              <div className="space-y-4">
                {mockAnalyticsData.monthlyEmissions.map((data) => (
                  <div key={data.month} className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <span className="text-sm font-medium text-slate-600 w-8">{data.month}</span>
                      <div className="w-48 h-3 bg-slate-200 rounded-full overflow-hidden">
                        <div 
                          className={`h-full rounded-full transition-all duration-500 ${
                            data.emissions <= data.target ? 'bg-emerald-500' : 'bg-orange-500'
                          }`}
                          style={{ width: `${Math.min((data.emissions / 4) * 100, 100)}%` }}
                        ></div>
                      </div>
                    </div>
                    <div className="text-sm font-semibold text-slate-700">{data.emissions}t</div>
                  </div>
                ))}
              </div>
              <div className="mt-4 pt-4 border-t border-slate-200/50">
                <div className="flex items-center justify-between text-xs text-slate-500">
                  <span>Target: 2.5t/month</span>
                  <span>Avg: {(mockAnalyticsData.monthlyEmissions.reduce((acc, curr) => acc + curr.emissions, 0) / mockAnalyticsData.monthlyEmissions.length).toFixed(1)}t</span>
                </div>
              </div>
            </div>

            {/* Emissions by Category */}
            <div className="bg-white/90 backdrop-blur-sm rounded-xl p-6 border border-slate-200/50 shadow-lg">
              <h3 className="text-lg font-semibold text-slate-800 mb-6">Emissions by Category</h3>
              <div className="space-y-4">
                {mockAnalyticsData.categories.map((category) => (
                  <div key={category.name} className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div className={`w-3 h-3 rounded-full ${category.color}`}></div>
                        <span className="text-sm font-medium text-slate-700">{category.name}</span>
                      </div>
                      <div className="text-sm font-semibold text-slate-700">{category.emissions}t</div>
                    </div>
                    <div className="w-full h-2 bg-slate-200 rounded-full overflow-hidden">
                      <div 
                        className={`h-full rounded-full transition-all duration-500 ${category.color}`}
                        style={{ width: `${category.percentage}%` }}
                      ></div>
                    </div>
                    <div className="text-xs text-slate-500">{category.percentage}% of total emissions</div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Insights and Recommendations */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
            {/* Carbon Insights */}
            <div className="lg:col-span-2 bg-white/90 backdrop-blur-sm rounded-xl p-6 border border-slate-200/50 shadow-lg">
              <h3 className="text-lg font-semibold text-slate-800 mb-6">Carbon Insights</h3>
              <div className="space-y-4">
                <div className="p-4 bg-emerald-50 rounded-lg border border-emerald-200">
                  <div className="flex items-start space-x-3">
                    <div className="w-8 h-8 bg-emerald-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <svg className="w-4 h-4 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
                      </svg>
                    </div>
                    <div>
                      <h4 className="font-semibold text-emerald-800 mb-1">Great Progress!</h4>
                      <p className="text-sm text-emerald-700">You've reduced your carbon footprint by 12% this month compared to last month. Keep up the excellent work!</p>
                    </div>
                  </div>
                </div>

                <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                  <div className="flex items-start space-x-3">
                    <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <svg className="w-4 h-4 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
                      </svg>
                    </div>
                    <div>
                      <h4 className="font-semibold text-blue-800 mb-1">Transportation Tip</h4>
                      <p className="text-sm text-blue-700">Transportation accounts for 45% of your emissions. Consider carpooling or using public transport 2 days a week to reduce by 18%.</p>
                    </div>
                  </div>
                </div>

                <div className="p-4 bg-amber-50 rounded-lg border border-amber-200">
                  <div className="flex items-start space-x-3">
                    <div className="w-8 h-8 bg-amber-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <svg className="w-4 h-4 text-amber-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                      </svg>
                    </div>
                    <div>
                      <h4 className="font-semibold text-amber-800 mb-1">Energy Efficiency</h4>
                      <p className="text-sm text-amber-700">Your energy usage increased slightly. Consider switching to LED bulbs and unplugging devices when not in use.</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Global Comparison */}
            <div className="bg-white/90 backdrop-blur-sm rounded-xl p-6 border border-slate-200/50 shadow-lg">
              <h3 className="text-lg font-semibold text-slate-800 mb-6">Global Comparison</h3>
              <div className="space-y-6">
                <div className="text-center">
                  <div className="text-3xl font-bold text-emerald-600 mb-2">2.4t</div>
                  <div className="text-sm text-slate-600">Your Annual CO₂</div>
                </div>

                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-slate-600">Global Average</span>
                    <span className="text-sm font-semibold text-slate-800">4.8t</span>
                  </div>
                  <div className="w-full h-2 bg-slate-200 rounded-full">
                    <div className="h-full bg-red-400 rounded-full" style={{ width: '100%' }}></div>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-slate-600">Your Emissions</span>
                    <span className="text-sm font-semibold text-emerald-600">2.4t</span>
                  </div>
                  <div className="w-full h-2 bg-slate-200 rounded-full">
                    <div className="h-full bg-emerald-500 rounded-full" style={{ width: '50%' }}></div>
                  </div>
                </div>

                <div className="text-center p-3 bg-emerald-50 rounded-lg border border-emerald-200">
                  <div className="text-sm font-semibold text-emerald-800">50% Below Average</div>
                  <div className="text-xs text-emerald-600 mt-1">You're doing amazing! Keep it up.</div>
                </div>
              </div>
            </div>
          </div>


        </div>
      </div>
    </div>
  );
};

export default Analytics;
